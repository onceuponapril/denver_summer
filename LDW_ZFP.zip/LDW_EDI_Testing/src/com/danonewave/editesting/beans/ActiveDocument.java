package com.danonewave.editesting.beans;

import java.util.ArrayList;
import java.util.List;

public class ActiveDocument implements Comparable<ActiveDocument> {
	public final static String FOLDER = "ActiveDocument";
	
	private String timestamp;
	private String mapName;
	private String originFile;
	private List<ADFile> inputFiles;
	private List<ADFile> outputFiles;
	private List<ErrorFile> errorFiles;
	private String result;
	
	public List<ErrorFile> getErrorFiles() {
		return errorFiles;
	}

	public void setErrorFiles(List<ErrorFile> errorFiles) {
		this.errorFiles = errorFiles;
	}

	private String errorDesc;
	private String errorMsg;
	
	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	
	

	public ActiveDocument(String timestamp) {
		this.timestamp = timestamp;
		inputFiles = new ArrayList<ADFile>();
		outputFiles = new ArrayList<ADFile>();
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getMapName() {
		return mapName;
	}

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}


	public String getOriginFile() {
		return originFile;
	}

	public void setOriginFile(String originFile) {
		this.originFile = originFile;
	}

	public List<ADFile> getInputFiles() {
		return inputFiles;
	}

	public void addInputFile(ADFile inputFile) {
		inputFiles.add(inputFile);
	}
	
	public List<ADFile> getOutputFiles() {
		return outputFiles;
	}

	public void addOutputFile(ADFile outputFile) {
		outputFiles.add(outputFile);
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	@Override
	public int compareTo(ActiveDocument activeDocument) {
		return activeDocument.timestamp.compareTo(this.timestamp);
	}
}
