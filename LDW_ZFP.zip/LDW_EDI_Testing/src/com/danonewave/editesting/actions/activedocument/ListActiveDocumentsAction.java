package com.danonewave.editesting.actions.activedocument;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;



import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.ADFile;
import com.danonewave.editesting.beans.ActiveDocument;
import com.danonewave.editesting.beans.Spec;
import com.danonewave.editesting.utils.SpecUtil;
import com.opensymphony.xwork2.ActionSupport;

public class ListActiveDocumentsAction extends ActionSupport {
	private static final long serialVersionUID = 9081428487470015931L;

	private List<ActiveDocument> activeDocumentList;

	public List<ActiveDocument> getActiveDocumentList() {
		return activeDocumentList;
	}

	public List<String> getMapNames() {
		return SpecUtil.listMapNames(ServletActionContext.getServletContext().getInitParameter("localDir")
				+ Spec.FOLDER + File.separator);
	}

	@Override
	public String execute() throws Exception {
		Hashtable<String, ActiveDocument> activeDocumentTable = new Hashtable<String, ActiveDocument>();

		String activeDocumentDir = (ServletActionContext.getServletContext().getInitParameter("localDir"))
				+ ActiveDocument.FOLDER + File.separator;

		for (String filename : new File(activeDocumentDir).list(new FilenameFilter() {
			@Override
			public boolean accept(File activeDocumentDir, String filename) {
				if (filename.endsWith(".DS_Store")){ 
				return false;
			}
				return true;
			}
		})){
			String timestamp = filename.substring(0, 17);
			ActiveDocument activeDocument = null;
			if (activeDocumentTable.containsKey(timestamp)) {
				activeDocument = activeDocumentTable.get(timestamp);
			} else {
				activeDocument = new ActiveDocument(timestamp);
				activeDocumentTable.put(timestamp, activeDocument);
			}
			if (filename.endsWith("origin.txt") || filename.endsWith("result.txt")) {
				int firstIndex = filename.indexOf("_");
				int secondIndex = filename.indexOf("_", firstIndex + 1);
				String mapName = filename.substring(firstIndex + 1, secondIndex);
				activeDocument.setMapName(mapName);

				if (filename.endsWith("origin.txt")) {
					activeDocument.setOriginFile(filename);
				}
				if (filename.endsWith("result.txt")) {
					activeDocument.setResult(FileUtils.readFileToString(new File(activeDocumentDir + filename)));
				}
			} else if (filename.endsWith("errors.xml")){
//				readfiletoString
				File file = new File(activeDocumentDir+filename);
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				DocumentBuilder db = dbf.newDocumentBuilder();
				Document doc = db.parse(file);

				String errorDesc=doc.getElementsByTagName("errorDesc").item(0).getTextContent();
				String errorMsg=doc.getElementsByTagName("errorMsg").item(0).getTextContent();
				activeDocument.setErrorDesc(errorDesc);
				activeDocument.setErrorMsg(errorMsg);
				
			}else {
				int firstIndex = filename.indexOf("_");
				int secondIndex = filename.indexOf("_", firstIndex + 1);
				int thirdIndex = filename.indexOf("_", secondIndex + 1);
				
				String type = filename.substring(firstIndex + 1, secondIndex);
				String contentId = filename.substring(secondIndex + 1, thirdIndex);
				String name = filename.substring(thirdIndex + 1);
				
				if (type.equals("input")){
					activeDocument.addInputFile(new ADFile(contentId, name, filename, null));
				}else if (type.equals("output")){
					activeDocument.addOutputFile(new ADFile(contentId, name, filename, null));
				}
			}

		}
	
		activeDocumentList = new ArrayList<ActiveDocument>(activeDocumentTable.values());
		Collections.sort(activeDocumentList);
		return SUCCESS;
	}
	
}


