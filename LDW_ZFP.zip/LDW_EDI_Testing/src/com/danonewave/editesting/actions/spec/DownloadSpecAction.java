package com.danonewave.editesting.actions.spec;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.Spec;
import com.opensymphony.xwork2.ActionSupport;

public class DownloadSpecAction extends ActionSupport {
	private static final long serialVersionUID = -8859399000723690252L;
	private String fileName;
	private long contentLength;
	private InputStream fileInputStream;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public InputStream getFileInputStream() {
		return fileInputStream;
	}

	public long getContentLength() {
		return contentLength;
	}

	@Override
	public String execute() throws Exception {
		File file = new File((ServletActionContext.getServletContext().getInitParameter("localDir"))
				+ Spec.FOLDER + File.separator + fileName);
		fileInputStream = new FileInputStream(file);
		contentLength = file.length();
		return SUCCESS;
	}
}
