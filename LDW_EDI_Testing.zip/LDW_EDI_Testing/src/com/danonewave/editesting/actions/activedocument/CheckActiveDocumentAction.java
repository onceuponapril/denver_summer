package com.danonewave.editesting.actions.activedocument;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.ADFile;
import com.danonewave.editesting.beans.ActiveDocument;
import com.danonewave.editesting.beans.EDI;
import com.danonewave.editesting.beans.Session;
import com.danonewave.editesting.utils.EDIUtil;
import com.danonewave.editesting.utils.TradingGridUtil;
import com.opensymphony.xwork2.ActionSupport;

public class CheckActiveDocumentAction extends ActionSupport {
	private static final long serialVersionUID = 2665995040547064006L;
	private String timestamp;
	private String mapName;

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public String execute() {
		String activeDocumentDir = ((String) ServletActionContext.getServletContext().getInitParameter("localDir"))
				+ ActiveDocument.FOLDER + File.separator;

		String message = null;

		EDI edi = EDIUtil.readEDI(new File(activeDocumentDir + timestamp + "_" + mapName + "_origin.txt"));
		if (edi == null) {
			message = "Failed to read original EDI file";
		} else {
			synchronized (TradingGridUtil.class) {
				Session session = new Session();
				CloseableHttpClient httpClient = TradingGridUtil.generateHttpClient(session.getCookies());
				try {
					TradingGridUtil.postLogin(httpClient,
							(String) ServletActionContext.getServletContext().getInitParameter("betagridUsername"),
							(String) ServletActionContext.getServletContext().getInitParameter("betagridPassword"));
					TradingGridUtil.getSearch(httpClient, session);
					TradingGridUtil.postSearchInboundByFG(httpClient, session, edi.getFunctionalGroup(), timestamp);
					TradingGridUtil.getSearchResponse(httpClient, session);
					if (session.getActiveDocuments().length == 0) {
						message = "Not found document in betagrid";
					} else if (session.getActiveDocuments().length == 1) {
						TradingGridUtil.getFile(httpClient, session);
						TradingGridUtil.getInputOutputFiles(httpClient, session);
						TradingGridUtil.listOutputFiles(httpClient, session);
						for (ADFile output : session.getOutputs()) {
							TradingGridUtil.exportFileStep1(httpClient, session, output);
							TradingGridUtil.exportFileStep2(httpClient, session, output,
									activeDocumentDir + timestamp + "_output_");
						}
						TradingGridUtil.listInputFiles(httpClient, session);
						for (ADFile input : session.getInputs()) {
							TradingGridUtil.exportFileStep1(httpClient, session, input);
							TradingGridUtil.exportFileStep2(httpClient, session, input,
									activeDocumentDir + timestamp + "_input_");
						}
						message = "Succeed to query betagride";
					} else if (session.getActiveDocuments().length > 1) {
						message = "Found multiple documents in betagrid: "
								+ Arrays.toString(session.getActiveDocuments());
					}
				} catch (Exception e) {
					message = e.toString();
					e.printStackTrace();
				} finally {
					try {
						httpClient.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}

		PrintWriter resultFileWriter = null;
		try {
			resultFileWriter = new PrintWriter(activeDocumentDir + timestamp + "_" + mapName + "_result.txt");
			resultFileWriter.write(message);
		} catch (FileNotFoundException e) {
		} finally {
			if (resultFileWriter != null) {
				resultFileWriter.close();
			}
		}
		return SUCCESS;
	}
}
