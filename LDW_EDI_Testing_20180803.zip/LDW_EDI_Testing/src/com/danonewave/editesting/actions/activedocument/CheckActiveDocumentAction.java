package com.danonewave.editesting.actions.activedocument;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.ServletContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.http.impl.client.CloseableHttpClient;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.danonewave.editesting.actions.RunnableAction;
import com.danonewave.editesting.beans.ADError;
import com.danonewave.editesting.beans.ADFile;
import com.danonewave.editesting.beans.ActiveDocument;
import com.danonewave.editesting.beans.EDI;
import com.danonewave.editesting.beans.Session;
import com.danonewave.editesting.utils.EDIUtil;
import com.danonewave.editesting.utils.TradingGridUtil;

public class CheckActiveDocumentAction extends RunnableAction {
	private static final long serialVersionUID = 2665995040547064006L;
	private String timestamp;
	private String mapName;

	public CheckActiveDocumentAction() {
		super();
	}

	public CheckActiveDocumentAction(ServletContext servletContext) {
		super(servletContext);
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public String execute() {
		String activeDocumentDir = (getParameter("localDir")) + ActiveDocument.FOLDER + File.separator;

		String message = null;

		EDI edi = EDIUtil.readEDI(new File(activeDocumentDir + timestamp + "_" + mapName + "_origin.txt"));
		if (edi == null) {
			message = "Failed to read original EDI file";
		} else {
			synchronized (TradingGridUtil.class) {
				Session session = new Session();
				CloseableHttpClient httpClient = TradingGridUtil.generateHttpClient(session.getCookies());
				try {
					TradingGridUtil.postLogin(httpClient, getParameter("betagridUsername"),
							getParameter("betagridPassword"));
					TradingGridUtil.getSearch(httpClient, session);
					TradingGridUtil.postSearchInboundDocumentByFG(httpClient, session, edi.getFunctionalGroup(),
							edi.getSender(), timestamp);
					TradingGridUtil.getSearchResponse(httpClient, session);
					if (session.getActiveDocuments().length == 0) {
						message = "Not found document in betagrid";
					} else if (session.getActiveDocuments().length == 1) {
						TradingGridUtil.getFile(httpClient, session);
						if (session.getErrorCount() == null) {
							TradingGridUtil.getInputOutputFiles(httpClient, session);
							TradingGridUtil.listOutputFiles(httpClient, session);
							for (ADFile output : session.getOutputs()) {
								TradingGridUtil.exportFileStep1(httpClient, session, output);
								TradingGridUtil.exportFileStep2(httpClient, session, output,
										activeDocumentDir + timestamp + "_output_");
							}
							TradingGridUtil.listInputFiles(httpClient, session);
							for (ADFile input : session.getInputs()) {
								TradingGridUtil.exportFileStep1(httpClient, session, input);
								TradingGridUtil.exportFileStep2(httpClient, session, input,
										activeDocumentDir + timestamp + "_input_");
							}
						} else {
							TradingGridUtil.postErrorsStep1(httpClient, session);
							TradingGridUtil.postErrorsStep2(httpClient, session);
							for (int i = 0; i < session.getErrors().length; i++) {
								TradingGridUtil.postErrorMsg(httpClient, session, i);
							}
							errorsToXml(activeDocumentDir, session.getErrors());
						}
						message = "Succeed to query betagride";
					} else if (session.getActiveDocuments().length > 1) {
						message = "Found multiple documents in betagrid: "
								+ Arrays.toString(session.getActiveDocuments());
					}
				} catch (Exception e) {
					message = e.toString();
					e.printStackTrace();
				} finally {
					try {
						httpClient.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}

		PrintWriter resultFileWriter = null;
		try {
			resultFileWriter = new PrintWriter(activeDocumentDir + timestamp + "_" + mapName + "_result.txt");
			resultFileWriter.write(message);
		} catch (FileNotFoundException e) {
		} finally {
			if (resultFileWriter != null) {
				resultFileWriter.close();
			}
		}
		return SUCCESS;
	}

	private void errorsToXml(String activeDocumentDir, ADError[] errors) throws Exception {
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

		Document doc = docBuilder.newDocument();
		Element rootElement = doc.createElement("Errors");
		doc.appendChild(rootElement);

		for (ADError error : errors) {
			Element errorElement = doc.createElement("Error");
			rootElement.appendChild(errorElement);

			Element errorCode = doc.createElement("Code");
			errorCode.appendChild(doc.createTextNode(error.getErrorCode()));
			errorElement.appendChild(errorCode);

			Element errorStatus = doc.createElement("Status");
			errorStatus.appendChild(doc.createTextNode(error.getErrorStatus()));
			errorElement.appendChild(errorStatus);

			Element errorDesc = doc.createElement("Desc");
			errorDesc.appendChild(doc.createTextNode(error.getErrorDesc()));
			errorElement.appendChild(errorDesc);

			Element errorMsg = doc.createElement("Msg");
			errorMsg.appendChild(doc.createTextNode(error.getErrorMsg()));
			errorElement.appendChild(errorMsg);
		}

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(activeDocumentDir + timestamp + "_" + mapName + "_errors.xml"));
		transformer.transform(source, result);
	}
}
