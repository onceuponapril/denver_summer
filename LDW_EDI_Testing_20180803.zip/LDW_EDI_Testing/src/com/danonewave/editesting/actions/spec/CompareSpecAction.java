package com.danonewave.editesting.actions.spec;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ComparisonOperator;
import org.apache.poi.ss.usermodel.ConditionalFormattingRule;
import org.apache.poi.ss.usermodel.PatternFormatting;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.SheetConditionalFormatting;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.Mapping;
import com.danonewave.editesting.beans.Spec;
import com.danonewave.editesting.beans.SpecComparison;
import com.opensymphony.xwork2.ActionSupport;

public class CompareSpecAction extends ActionSupport {
	private static final long serialVersionUID = -7588030462154416345L;
	private static final String[] COLUMN_NAMES = new String[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K",
			"L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };

	private String[] fileNames;
	private String sheetName;
	private String recordColumn;
	private String fieldColumn;
	private String contentColumns;

	public void setFileNames(String[] fileNames) {
		this.fileNames = fileNames;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	public void setRecordColumn(String recordColumn) {
		this.recordColumn = recordColumn;
	}

	public void setFieldColumn(String fieldColumn) {
		this.fieldColumn = fieldColumn;
	}

	public void setContentColumns(String contentColumns) {
		this.contentColumns = contentColumns;
	}

	public String execute() {
		String specDir = ((String) ServletActionContext.getServletContext().getInitParameter("localDir")) + Spec.FOLDER
				+ File.separator;
		String specComparisonDir = ((String) ServletActionContext.getServletContext().getInitParameter("localDir"))
				+ SpecComparison.FOLDER + File.separator;

		new CompareThread(fileNames, sheetName, recordColumn, fieldColumn, contentColumns, specDir, specComparisonDir)
				.start();

		return SUCCESS;
	}

	private class CompareThread extends Thread {

		private String[] fileNames;
		private String sheetName;
		private String recordColumn;
		private String fieldColumn;
		private String contentColumns;
		private String specDir;
		private String specComparisonDir;

		public CompareThread(String[] fileNames, String sheetName, String recordColumn, String fieldColumn,
				String contentColumns, String specDir, String specComparisonDir) {
			this.fileNames = fileNames;
			this.sheetName = sheetName;
			this.recordColumn = recordColumn;
			this.fieldColumn = fieldColumn;
			this.contentColumns = contentColumns;
			this.specDir = specDir;
			this.specComparisonDir = specComparisonDir;
		}

		public void run() {
			String timestamp = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
			String result = null;
			String mapNames = "";
			if (fileNames != null && fileNames.length > 1) {
				String[] specFilenames = new String[fileNames.length];
				for (int i = 0; i < specFilenames.length; i++) {
					specFilenames[i] = specDir + fileNames[i];
					mapNames += (fileNames[i].substring(0, fileNames[i].lastIndexOf(".")) + "_");
				}

				if (result == null) {
					Workbook report = new XSSFWorkbook();
					Sheet reportSheet = report.createSheet("report");
					List<Hashtable<String, List<Mapping>>> mappings = new ArrayList<Hashtable<String, List<Mapping>>>();
					OutputStream fileOut = null;
					try {
						int recordColumnInt = Integer.valueOf(recordColumn);
						int fieldColumnInt = Integer.valueOf(fieldColumn);
						int[] contentColumnsInt = parseContentColumn(contentColumns);
						for (int i = 0; i < specFilenames.length; i++) {
							mappings.add(readEdiSpec(specFilenames[i], sheetName, recordColumnInt, fieldColumnInt,
									contentColumnsInt));

						}
						compare(mappings, reportSheet, contentColumnsInt);

						fileOut = new FileOutputStream(specComparisonDir + timestamp + "_" + mapNames + "report.xlsx");
						report.write(fileOut);
						report.close();
						result = "Success";
					} catch (Exception e) {
						result = e.toString();
					} finally {
						if (fileOut != null) {
							try {
								fileOut.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
				}
			} else {
				result = "At least two specs are required";
			}
			PrintWriter resultFileWriter = null;
			try {
				resultFileWriter = new PrintWriter(specComparisonDir + timestamp + "_" + mapNames + "result.txt");
				resultFileWriter.write(result);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} finally {
				if (resultFileWriter != null) {
					resultFileWriter.close();
				}
			}

		}
	}

	private static Hashtable<String, List<Mapping>> readEdiSpec(String ediSpecFilename, String sheetName,
			int recordColumn, int fieldColumn, int[] contentColumns) throws Exception {
		Workbook ediSpec = WorkbookFactory.create(new File(ediSpecFilename));
		Sheet ediSpecSheet = ediSpec.getSheet(sheetName);
		String record = null, field = null;
		Hashtable<String, List<Mapping>> mappings = new Hashtable<String, List<Mapping>>();
		for (int i = ediSpecSheet.getFirstRowNum(); i < ediSpecSheet.getLastRowNum(); i++) {
			Row row = ediSpecSheet.getRow(i);
			if (row != null) {
				Cell recordCell = row.getCell(recordColumn);
				if (recordCell != null && !recordCell.getStringCellValue().isEmpty()) {
					record = recordCell.getStringCellValue();
				}
				Cell fieldCell = row.getCell(fieldColumn);
				if (fieldCell == null) {
					field = "";
				} else {
					field = fieldCell.getStringCellValue();
				}
				String key = record + "|" + field;
				List<Mapping> mapping = null;
				if (mappings.containsKey(key)) {
					mapping = mappings.get(key);
				} else {
					mapping = new ArrayList<Mapping>();
					mappings.put(key, mapping);
				}
				mapping.add(new Mapping(i + 1, record, field, row.getZeroHeight(), readContent(row, contentColumns)));
			}
		}
		return mappings;
	}

	private static String[] readContent(Row row, int[] columns) {
		String[] content = new String[columns.length];
		for (int i = 0; i < columns.length; i++) {
			Cell cell = row.getCell(columns[i]);
			if (cell == null) {
				content[i] = "";
			} else {
				content[i] = cell.getStringCellValue();
			}
		}
		return content;
	}

	private static int[] parseContentColumn(String columns) {
		String[] columnStringArray = columns.split(",");
		int[] columnIntArray = new int[columnStringArray.length];
		for (int i = 0; i < columnIntArray.length; i++) {
			columnIntArray[i] = Integer.parseInt(columnStringArray[i]);
		}
		return columnIntArray;
	}

	private static void compare(List<Hashtable<String, List<Mapping>>> mappings, Sheet reportSheet,
			int[] contentColumns) {
		int rowNum = 0;
		int columnNum = 0;
		int mappingsNum = mappings.size();

		CellStyle wrapTextStyle = reportSheet.getWorkbook().createCellStyle();
		wrapTextStyle.setWrapText(true);

		SheetConditionalFormatting scf = reportSheet.getSheetConditionalFormatting();
		ConditionalFormattingRule rule = scf.createConditionalFormattingRule(ComparisonOperator.EQUAL, "FALSE", null);
		PatternFormatting patternFormatting = rule.createPatternFormatting();
		patternFormatting.setFillBackgroundColor((short) 2);

		List<Integer> formulaColumns = new ArrayList<Integer>();

		Row headerRow = reportSheet.createRow(rowNum++);
		Cell recordHeaderCell = headerRow.createCell(columnNum);
		recordHeaderCell.setCellValue("Record");
		reportSheet.setColumnWidth(columnNum++, 4000);
		Cell fieldHeaderCell = headerRow.createCell(columnNum);
		fieldHeaderCell.setCellValue("Field");
		reportSheet.setColumnWidth(columnNum++, 4000);
		for (int i = 1; i <= mappingsNum; i++) {
			Cell rowHeaderCell = headerRow.createCell(columnNum);
			rowHeaderCell.setCellValue("Row" + i);
			reportSheet.setColumnWidth(columnNum++, 3000);
		}
		for (int i = 0; i < contentColumns.length; i++) {
			String formulaHeaderValue = "";
			for (int j = 1; j <= mappingsNum; j++) {
				Cell contentHeaderCell = headerRow.createCell(columnNum);
				contentHeaderCell.setCellValue(getColumnName(contentColumns[i]) + j);
				reportSheet.setColumnWidth(columnNum++, 6000);
				formulaHeaderValue = formulaHeaderValue.length() == 0 ? getColumnName(contentColumns[i]) + j
						: formulaHeaderValue + " = " + getColumnName(contentColumns[i]) + j;
			}
			formulaHeaderValue += "?";
			Cell contentFormulaHeaderCell = headerRow.createCell(columnNum);
			contentFormulaHeaderCell.setCellValue(formulaHeaderValue);
			formulaColumns.add(columnNum);
			reportSheet.setColumnWidth(columnNum++, 3000);
		}

		for (int i = 1; i <= mappingsNum; i++) {
			Hashtable<String, List<Mapping>> mapping = mappings.get(i - 1);
			for (String key : mapping.keySet()) {
				for (Mapping mapping1 : mapping.get(key)) {
					if (!mapping1.isHidden() && !mapping1.isProcessed()) {
						List<String[]> contents = new ArrayList<String[]>();
						Row row = reportSheet.createRow(rowNum++);
						row.createCell(columnNum++).setCellValue(mapping1.getRecord());
						row.createCell(columnNum++).setCellValue(mapping1.getField());
						for (int j = 1; j < i; j++) {
							row.createCell(columnNum++).setCellValue("");
							String[] content = new String[contentColumns.length];
							for (int k = 0; k < content.length; k++) {
								content[k] = "";
							}
							contents.add(content);
						}
						row.createCell(columnNum++).setCellValue(mapping1.getRowNum());
						contents.add(mapping1.getContent());
						for (int j = i; j < mappingsNum; j++) {
							Mapping mapping2 = findMapping(mappings.get(j).get(key), mapping1);
							if (mapping2 == null) {
								row.createCell(columnNum++).setCellValue("");
								contents.add(new String[contentColumns.length]);
							} else {
								row.createCell(columnNum++).setCellValue(mapping2.getRowNum());
								contents.add(mapping2.getContent());
								mapping2.setProcessed();
							}
						}
						if (isDifferent(contents)) {
							for (int k = 0; k < contentColumns.length; k++) {
								String formulaValue = "";
								for (int j = 1; j <= mappingsNum; j++) {
									Cell contentCell = row.createCell(columnNum++);
									contentCell.setCellValue(contents.get(j - 1)[k]);
									contentCell.setCellStyle(wrapTextStyle);
									if (j != mappingsNum) {
										formulaValue = formulaValue.length() == 0
												? getColumnName(columnNum - 1) + (row.getRowNum() + 1) + "="
														+ getColumnName(columnNum) + (row.getRowNum() + 1)
												: formulaValue + "," + getColumnName(columnNum - 1)
														+ (row.getRowNum() + 1) + "=" + getColumnName(columnNum)
														+ (row.getRowNum() + 1);
									}
								}
								row.createCell(columnNum++).setCellFormula("AND(" + formulaValue + ")");
							}
						} else {
							reportSheet.removeRow(row);
							rowNum--;
						}
						columnNum = 0;
					}
				}
			}
		}

		List<CellRangeAddress> regions = new ArrayList<CellRangeAddress>();
		for (Integer formulaColumn : formulaColumns) {
			regions.add(new CellRangeAddress(1, reportSheet.getLastRowNum(), formulaColumn, formulaColumn));
		}
		scf.addConditionalFormatting(regions.toArray(new CellRangeAddress[regions.size()]), rule);
	}

	private static Mapping findMapping(List<Mapping> mappings, Mapping baseMapping) {
		Mapping closedMapping = null;
		if (mappings != null) {
			closedMapping = findMappingWithRange(mappings, baseMapping, 3);
			if (closedMapping == null) {
				closedMapping = findMappingWithRange(mappings, baseMapping, 10);
				if (closedMapping == null) {
					closedMapping = findMappingWithRange(mappings, baseMapping, 50);
					if (closedMapping == null) {
						closedMapping = findMappingWithRange(mappings, baseMapping, 100);
						if (closedMapping == null) {
							closedMapping = findMappingWithRange(mappings, baseMapping, 200);
							if (closedMapping == null) {
								closedMapping = findMappingWithRange(mappings, baseMapping, 500);
							}
						}
					}
				}
			}
		}
		return closedMapping;
	}

	private static Mapping findMappingWithRange(List<Mapping> mappings, Mapping baseMapping, int range) {
		int minRange = Integer.MAX_VALUE;
		Mapping closedMapping = null;
		if (mappings != null) {
			for (Mapping mapping : mappings) {
				int mappingRange = Math.abs(mapping.getRowNum() - baseMapping.getRowNum());
				if (mappingRange < range && mappingRange < minRange) {
					minRange = mappingRange;
					closedMapping = mapping;
				}
			}
		}
		return closedMapping;
	}

	private static String getColumnName(int columnNum) {
		return COLUMN_NAMES[columnNum];
	}

	private static boolean isDifferent(List<String[]> contents) {
		for (int i = 1; i < contents.size(); i++) {
			for (int j = 0; j < contents.get(0).length; j++) {
				if (!contents.get(0)[j].equals(contents.get(i)[j])) {
					return true;
				}
			}
		}
		return false;
	}
}
