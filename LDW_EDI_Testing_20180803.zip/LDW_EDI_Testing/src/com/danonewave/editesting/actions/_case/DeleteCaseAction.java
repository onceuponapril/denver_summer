package com.danonewave.editesting.actions._case;

import java.io.File;
import java.io.FilenameFilter;

import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.Case;
import com.opensymphony.xwork2.ActionSupport;

public class DeleteCaseAction extends ActionSupport {
	private static final long serialVersionUID = 2266479612613884845L;
	private String mapName;
	private String caseName;

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public void setCaseName(String caseName) {
		this.caseName = caseName;
	}

	public String execute() throws Exception {
		File caseDir = new File(((String) ServletActionContext.getServletContext().getInitParameter("localDir"))
				+ Case.FOLDER + File.separator + mapName);
		for (String filename : caseDir.list(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				if (name.startsWith(caseName)) {
					return true;
				}
				return false;
			}
		})) {
			new File(caseDir.getAbsolutePath() + File.separator + filename).delete();
		}
		return SUCCESS;
	}

}
