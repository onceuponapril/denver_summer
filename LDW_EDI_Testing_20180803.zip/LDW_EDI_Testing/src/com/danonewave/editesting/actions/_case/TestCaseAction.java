package com.danonewave.editesting.actions._case;


import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

public class TestCaseAction extends ActionSupport {

	private static final long serialVersionUID = -5978062120727797566L;
	private String mapName;
	private String[] caseNames;

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public void setCaseNames(String[] caseNames) {
		this.caseNames = caseNames;
	}

	public String execute() throws Exception {
		new TestCaseThread(mapName, caseNames, ServletActionContext.getServletContext()).start();
		return SUCCESS;
	}

}
