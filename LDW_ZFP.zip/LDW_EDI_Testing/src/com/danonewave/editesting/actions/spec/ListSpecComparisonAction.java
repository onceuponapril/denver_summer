package com.danonewave.editesting.actions.spec;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.SpecComparison;
import com.opensymphony.xwork2.ActionSupport;

public class ListSpecComparisonAction extends ActionSupport {
	private static final long serialVersionUID = 8278745087365648599L;
	private List<SpecComparison> specComparisonList;

	public List<SpecComparison> getSpecComparisonList() {
		return specComparisonList;
	}

	@Override
	public String execute() throws Exception {
		Hashtable<String, SpecComparison> specComparisonHashtable = new Hashtable<String, SpecComparison>();
		String specComparisonDir = (ServletActionContext.getServletContext().getInitParameter("localDir")) + SpecComparison.FOLDER
				+ File.separator;

		for (String filename : new File(specComparisonDir).list(new FilenameFilter(){

				@Override
				public boolean accept(File activeDocumentDir, String filename) {
					if (filename.endsWith(".DS_Store")){ 
					return false;
				}
					return true;
				}
		    })) {
			String timestamp = filename.substring(0, 17);
			SpecComparison specComparison = null;
			if (specComparisonHashtable.containsKey(timestamp)){
				specComparison = specComparisonHashtable.get(timestamp);
				if (filename.endsWith("result.txt")){
					specComparison.setResult(FileUtils.readFileToString(new File(specComparisonDir + filename)));
				}
				if (filename.endsWith("report.xlsx")){
					specComparison.setReportFile(filename);
				}
			}else{
				if (filename.endsWith("result.txt")){
					String mapNames = filename.substring(18, filename.length() - 11);
					specComparison = new SpecComparison(timestamp, mapNames, FileUtils.readFileToString(new File(specComparisonDir + filename)), null);
					specComparisonHashtable.put(timestamp, specComparison);
				}
				if (filename.endsWith("report.xlsx")){
					String mapNames = filename.substring(18, filename.length() - 12);
					specComparison = new SpecComparison(timestamp, mapNames, null, filename);
					specComparisonHashtable.put(timestamp, specComparison);
				}
			}
		}

		specComparisonList = new ArrayList<SpecComparison>(specComparisonHashtable.values());
		Collections.sort(specComparisonList);
		return SUCCESS;
	}
}
