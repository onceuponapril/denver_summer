package com.danonewave.editesting.actions.activedocument;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.danonewave.editesting.actions.RunnableAction;
import com.danonewave.editesting.beans.ADError;
import com.danonewave.editesting.beans.ADFile;
import com.danonewave.editesting.beans.ActiveDocument;
import com.danonewave.editesting.beans.Spec;
import com.danonewave.editesting.utils.SpecUtil;

public class ListActiveDocumentsAction extends RunnableAction {
	private static final long serialVersionUID = 9081428487470015931L;

	private List<String> timestamps;
	private List<ActiveDocument> activeDocumentList;

	public ListActiveDocumentsAction() {
		super();
	}

	public ListActiveDocumentsAction(ServletContext servletContext) {
		super(servletContext);
	}

	public List<ActiveDocument> getActiveDocumentList() {
		return activeDocumentList;
	}

	public void setTimestamps(Set<String> timestamps) {
		this.timestamps = new ArrayList<String>();
		this.timestamps.addAll(timestamps);
	}

	public void setTimestampValue(String timestamp) {
		this.timestamps = new ArrayList<String>();
		this.timestamps.add(timestamp);
	}

	public List<String> getMapNames() {
		return SpecUtil.listMapNames(getParameter("localDir") + Spec.FOLDER + File.separator);
	}

	public String execute() throws Exception {
		Hashtable<String, ActiveDocument> activeDocumentTable = new Hashtable<String, ActiveDocument>();

		String activeDocumentDir = (getParameter("localDir")) + ActiveDocument.FOLDER + File.separator;

		for (String filename : new File(activeDocumentDir).list()) {
			String timestamp = filename.substring(0, 17);
			if (timestamps != null && !timestamps.contains(timestamp)) {
				continue;
			}
			ActiveDocument activeDocument = null;
			if (activeDocumentTable.containsKey(timestamp)) {
				activeDocument = activeDocumentTable.get(timestamp);
			} else {
				activeDocument = new ActiveDocument(new SimpleDateFormat("yyyyMMddHHmmssSSS").parse(timestamp));
				activeDocumentTable.put(timestamp, activeDocument);
			}
			if (filename.endsWith("origin.txt") || filename.endsWith("result.txt")) {
				int firstIndex = filename.indexOf("_");
				int secondIndex = filename.indexOf("_", firstIndex + 1);
				String mapName = filename.substring(firstIndex + 1, secondIndex);
				activeDocument.setMapName(mapName);

				if (filename.endsWith("origin.txt")) {
					activeDocument.setOriginFile(filename);
				}
				if (filename.endsWith("result.txt")) {
					activeDocument.setResult(FileUtils.readFileToString(new File(activeDocumentDir + filename)));
				}
			} else if (filename.endsWith("errors.xml")) {
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				DocumentBuilder db = dbf.newDocumentBuilder();
				Document doc = db.parse(new File(activeDocumentDir + filename));

				Element rootElement = doc.getDocumentElement();

				NodeList nodeList = rootElement.getChildNodes();
				for (int i = 0; i < nodeList.getLength(); i++) {
					Node errorNode = nodeList.item(i);
					ADError error = new ADError(null, null, null, null);
					error.setErrorDesc(((Element) errorNode).getElementsByTagName("Desc").item(0).getTextContent());
					error.setErrorMsg(((Element) errorNode).getElementsByTagName("Msg").item(0).getTextContent());
					activeDocument.addError(error);
				}
			} else {
				int firstIndex = filename.indexOf("_");
				int secondIndex = filename.indexOf("_", firstIndex + 1);
				int thirdIndex = filename.indexOf("_", secondIndex + 1);

				String type = filename.substring(firstIndex + 1, secondIndex);
				String contentId = filename.substring(secondIndex + 1, thirdIndex);
				String name = filename.substring(thirdIndex + 1);

				if (type.equals("input")) {
					activeDocument.addInputFile(new ADFile(contentId, name, filename, null));
				} else if (type.equals("output")) {
					activeDocument.addOutputFile(new ADFile(contentId, name, filename, null));
				}
			}
		}

		activeDocumentList = new ArrayList<ActiveDocument>(activeDocumentTable.values());
		Collections.sort(activeDocumentList);
		return SUCCESS;
	}

}
