package com.danonewave.editesting.beans;

public class Case {
	public final static String FOLDER = "Case";
	public final static String TEST_FOLDER = "Test";
	public final static String KEY_PATTERN = "pattern";
	public final static String KEY_RECORDS = "records";
	
	private String caseName;
	private String inputFile;
	private String outputFile;
	private String outputFilePattern;
	private String[] records;

	public Case(String caseName) {
		this.caseName = caseName;
	}

	public String getCaseName() {
		return caseName;
	}

	public void setCaseName(String caseName) {
		this.caseName = caseName;
	}

	public String getInputFile() {
		return inputFile;
	}

	public void setInputFile(String inputFile) {
		this.inputFile = inputFile;
	}

	public String getOutputFile() {
		return outputFile;
	}

	public void setOutputFile(String outputFile) {
		this.outputFile = outputFile;
	}

	public String getOutputFilePattern() {
		return outputFilePattern;
	}

	public void setOutputFilePattern(String outputFilePattern) {
		this.outputFilePattern = outputFilePattern;
	}

	public String[] getRecords() {
		return records;
	}

	public void setRecords(String[] records) {
		this.records = records;
	}
}
