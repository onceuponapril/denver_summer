package com.danonewave.editesting.actions.target2;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.Spec;
import com.danonewave.editesting.beans.Target2;
import com.danonewave.editesting.utils.SpecUtil;
import com.opensymphony.xwork2.ActionSupport;

public class ListTarget2Action extends ActionSupport {
	private static final long serialVersionUID = 188677787642608788L;
	private List<Target2> target2List;

	public List<Target2> getTarget2List() {
		return target2List;
	}

	public List<String> getMapNames() {
		return SpecUtil.listMapNames((String) ServletActionContext.getServletContext().getInitParameter("localDir")
				+ Spec.FOLDER + File.separator);
	}

	public String execute() throws Exception {
		Hashtable<String, Target2> targetTable = new Hashtable<String, Target2>();

		String target2Dir = ((String) ServletActionContext.getServletContext().getInitParameter("localDir"))
				+ Target2.FOLDER + File.separator;

		for (String filename : new File(target2Dir).list(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String filename) {
				if (filename.endsWith(".txt")) {
					return true;
				}
				return false;
			}
		})) {

			String timestamp = filename.substring(0, 17);

			int firstIndex = filename.indexOf("_");
			int secondIndex = filename.indexOf("_", firstIndex + 1);
			String mapName = filename.substring(firstIndex + 1, secondIndex);
			String type = filename.substring(secondIndex + 1, filename.length() - 4);

			Target2 target2 = null;
			if (targetTable.containsKey(timestamp)) {
				target2 = targetTable.get(timestamp);
			} else {
				target2 = new Target2(timestamp, mapName, null, null, null);
				targetTable.put(timestamp, target2);
			}
			switch (type) {
			case "edi":
				target2.setEdiFile(filename);
				break;
			case "email":
				target2.setEmailFile(filename);
				break;
			case "result":
				target2.setResult(FileUtils.readFileToString(new File(target2Dir + filename)));
				break;
			}
		}

		target2List = new ArrayList<Target2>(targetTable.values());
		Collections.sort(target2List);
		return SUCCESS;
	}
}
