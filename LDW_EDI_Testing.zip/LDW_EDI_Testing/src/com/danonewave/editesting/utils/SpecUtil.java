package com.danonewave.editesting.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SpecUtil {
	public static List<String> listMapNames(String dir){
		Set<String> mapNameSet = new HashSet<String>();
		for (String filename : new File(dir).list()){
			mapNameSet.add(filename.substring(0, filename.indexOf('_')));
		}
		List<String> mapNameList = new ArrayList<String>(mapNameSet);
		Collections.sort(mapNameList);
		return mapNameList;
	}
}
