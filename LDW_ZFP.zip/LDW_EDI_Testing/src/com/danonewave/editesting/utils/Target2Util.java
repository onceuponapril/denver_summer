package com.danonewave.editesting.utils;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Target2Util {

public static List<String> listTargetMapNames(String dir){
	Set<String> mapNameSet = new HashSet<String>();
	for (String filename : new File(dir).list(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String filename) {
				if (filename.contains(".DS_Store")) {
					return false;
				}
				return true;
			}
		})) {
		int firstIndex = filename.indexOf("_");
		int secondIndex = filename.indexOf("_", firstIndex + 1);
		mapNameSet.add(filename.substring(firstIndex + 1, secondIndex));
	}
	List<String> mapNameList = new ArrayList<String>(mapNameSet);
	Collections.sort(mapNameList);
	return mapNameList;
}
}