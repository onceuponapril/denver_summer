package com.danonewave.editesting.actions._case;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.actions.activedocument.ListActiveDocumentsAction;
import com.danonewave.editesting.beans.ADFile;
import com.danonewave.editesting.beans.ActiveDocument;
import com.danonewave.editesting.beans.Case;
import com.danonewave.editesting.beans.TestReportEntry;
import com.opensymphony.xwork2.ActionSupport;

public class ViewReportAction extends ActionSupport {
	private static final long serialVersionUID = 9094762574149905758L;
	private String reportFile;
	private List<TestReportEntry> reportEntries;

	public void setReportFile(String reportFile) {
		this.reportFile = reportFile;
	}
	
	public String getReportFile(){
		return reportFile;
	}

	public List<TestReportEntry> getReportEntries() {
		return reportEntries;
	}

	public String execute() throws Exception {
		reportEntries = new ArrayList<TestReportEntry>();
		String testDir = ((String) ServletActionContext.getServletContext().getInitParameter("localDir"))
				+ Case.TEST_FOLDER + File.separator;

		FileReader reportFileReader = null;
		BufferedReader reportFileBufferedReader = null;
		String reportLine = null;
		try {
			reportFileReader = new FileReader(testDir + reportFile);
			reportFileBufferedReader = new BufferedReader(reportFileReader);

			while ((reportLine = reportFileBufferedReader.readLine()) != null) {
				String[] reportEntry = reportLine.split(";");
				ListActiveDocumentsAction listActiveDocumentsAction = new ListActiveDocumentsAction();
				listActiveDocumentsAction.setTimestampValue(reportEntry[0]);
				listActiveDocumentsAction.execute();
				for (ActiveDocument activeDocument : listActiveDocumentsAction.getActiveDocumentList()) {
					reportEntries.add(
							new TestReportEntry(reportEntry[2], activeDocument.getInputFiles().toArray(new ADFile[activeDocument.getInputFiles().size()]),
									activeDocument.getOutputFiles().toArray(new ADFile[activeDocument.getOutputFiles().size()]), reportEntry[3]));
					break;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reportFileBufferedReader != null) {
				try {
					reportFileBufferedReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			if (reportFileReader != null) {
				try {
					reportFileReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return SUCCESS;
	}
}
