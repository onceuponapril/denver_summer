package com.danonewave.editesting.actions._case;

import com.opensymphony.xwork2.ActionSupport;

public class DownloadActiveDocumentAction extends ActionSupport {
	private static final long serialVersionUID = 1160597907631377873L;
	private String fileName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String execute() throws Exception {
	
		return SUCCESS;
	}
}
