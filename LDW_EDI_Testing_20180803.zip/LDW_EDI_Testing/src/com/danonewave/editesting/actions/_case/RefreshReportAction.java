package com.danonewave.editesting.actions._case;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;

import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.actions.activedocument.ListActiveDocumentsAction;
import com.danonewave.editesting.beans.ADFile;
import com.danonewave.editesting.beans.ActiveDocument;
import com.danonewave.editesting.beans.Case;
import com.danonewave.editesting.utils.IDocComparator;
import com.opensymphony.xwork2.ActionSupport;

public class RefreshReportAction extends ActionSupport {

	private static final long serialVersionUID = 935921701542189381L;
	private String reportFile;

	public void setReportFile(String reportFile) {
		this.reportFile = reportFile;
	}

	public String execute() throws Exception {
		String testDir = ((String) ServletActionContext.getServletContext().getInitParameter("localDir"))
				+ Case.TEST_FOLDER + File.separator;
		String activeDocumentDir = ((String) ServletActionContext.getServletContext().getInitParameter("localDir"))
				+ ActiveDocument.FOLDER + File.separator;

		StringBuffer reportStringBuffer = new StringBuffer();
		FileReader reportFileReader = null;
		BufferedReader reportFileBufferedReader = null;
		String reportLine = null;
		try {
			reportFileReader = new FileReader(testDir + reportFile);
			reportFileBufferedReader = new BufferedReader(reportFileReader);

			while ((reportLine = reportFileBufferedReader.readLine()) != null) {
				String[] reportEntry = reportLine.split(";");
				ListActiveDocumentsAction listActiveDocumentsAction = new ListActiveDocumentsAction(
						ServletActionContext.getServletContext());
				listActiveDocumentsAction.setTimestampValue(reportEntry[0]);

				String caseDir = ((String) ServletActionContext.getServletContext().getInitParameter("localDir"))
						+ Case.FOLDER + File.separator + reportEntry[1] + File.separator;
				try {
					listActiveDocumentsAction.execute();
					for (ActiveDocument activeDocument : listActiveDocumentsAction.getActiveDocumentList()) {
						String caseId = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(activeDocument.getTimestamp());
						Case _case = IDocComparator.getCase(reportEntry[2], ServletActionContext.getServletContext(),
								reportEntry[1]);
						String outputPattern = _case.getOutputFilePattern();
						String[] records = _case.getRecords();
						reportStringBuffer.append(caseId + ";" + reportEntry[1] + ";" + _case.getCaseName() + ";" );
						String compareResult = "Unknown";
						for (ADFile output : activeDocument.getOutputFiles()) {
							String outputFilename = output.getFileName();
							if (outputFilename.matches(outputPattern)) {
								compareResult = IDocComparator.compare(
										new File(activeDocumentDir + output.getFileUri()),
										new File(caseDir + _case.getOutputFile()), records);
								break;
							}
						}
						reportStringBuffer.append(compareResult + "\n");
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reportFileBufferedReader != null) {
				try {
					reportFileBufferedReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			if (reportFileReader != null) {
				try {
					reportFileReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		PrintWriter reportFileWriter = null;
		try {
			reportFileWriter = new PrintWriter(testDir + reportFile);
			reportFileWriter.write(reportStringBuffer.toString());
		} catch (FileNotFoundException e) {
		} finally {
			if (reportFileWriter != null) {
				reportFileWriter.close();
			}
		}
		return SUCCESS;
	}

}
