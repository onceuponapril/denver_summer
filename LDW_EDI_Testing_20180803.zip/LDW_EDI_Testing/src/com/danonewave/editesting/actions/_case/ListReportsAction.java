package com.danonewave.editesting.actions._case;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.Case;
import com.danonewave.editesting.beans.CaseTest;
import com.opensymphony.xwork2.ActionSupport;

public class ListReportsAction extends ActionSupport {
	private static final long serialVersionUID = 5694444556079148624L;
	private List<CaseTest> caseTestList;

	public List<CaseTest> getCaseTestList() {
		return caseTestList;
	}

	public String execute() throws Exception {
		String testDir = ((String) ServletActionContext.getServletContext().getInitParameter("localDir"))
				+ Case.TEST_FOLDER + File.separator;
		Hashtable<String, CaseTest> caseTestTable = new Hashtable<String, CaseTest>();
		caseTestList = new ArrayList<CaseTest>();
		for (String filename : new File(testDir).list()) {
			String timestamp = filename.substring(0, 17);
			String mapName = filename.substring(18, filename.lastIndexOf('_'));
			CaseTest caseTest = null;
			if (caseTestTable.containsKey(timestamp)){
				caseTest = caseTestTable.get(timestamp);
			}else{
				caseTest = new CaseTest(new SimpleDateFormat("yyyyMMddHHmmssSSS").parse(timestamp), mapName);
				caseTestTable.put(timestamp, caseTest);
			}
			if (filename.endsWith("result.txt")){
				caseTest.setResult(FileUtils.readFileToString(new File(testDir + filename)));
			}

			if (filename.endsWith("report.txt")){
				caseTest.setReportFile(filename);
			}
		}
		caseTestList = new ArrayList<CaseTest>(caseTestTable.values());
		Collections.sort(caseTestList);
		return SUCCESS;
	}
}
