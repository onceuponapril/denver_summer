package com.danonewave.editesting.actions.spec;

import java.io.File;
import org.apache.struts2.ServletActionContext;
import com.danonewave.editesting.beans.Spec;
import com.opensymphony.xwork2.ActionSupport;

public class DeleteSpecAction extends ActionSupport {
	private static final long serialVersionUID = 351669155107159484L;
	private String fileName;

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String execute() throws Exception {
		new File(((String) ServletActionContext.getServletContext().getInitParameter("localDir")) + Spec.FOLDER
				+ File.separator + fileName).delete();
		return SUCCESS;
	}

}
