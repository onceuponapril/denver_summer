package com.danonewave.editesting.actions.activedocument;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.danonewave.editesting.actions._case.UploadCaseAction;
import com.danonewave.editesting.beans.ActiveDocument;
import com.danonewave.editesting.beans.Case;

public class ActiveDocument2CaseAction extends ActionSupport {
	private static final long serialVersionUID = -2859048518936352869L;
	private String outputFilename;
	private String caseName;
	private String outputFilePattern;
	private String records;

	public void setOutputFilename(String outputFilename) {
		this.outputFilename = outputFilename;
	}

	public void setCaseName(String caseName) {
		this.caseName = caseName;
	}

	public void setOutputFilePattern(String outputFilePattern) {
		this.outputFilePattern = outputFilePattern;
	}

	public void setRecords(String records) {
		this.records = records;
	}

	public String execute() throws IOException {
		String timestamp = outputFilename.substring(0, 17);
		File activeDocumentDir = new File(
				((String) ServletActionContext.getServletContext().getInitParameter("localDir"))
						+ ActiveDocument.FOLDER);

		for (String filename : activeDocumentDir.list()) {
			if (filename.startsWith(timestamp) && filename.endsWith("origin.txt")) {
				String mapName = filename.substring(filename.indexOf("_") + 1, filename.lastIndexOf("_"));
				File inputFile = new File(
						((String) ServletActionContext.getServletContext().getInitParameter("localDir")) + Case.FOLDER
								+ File.separator + mapName + File.separator + filename);
				File outputFile = new File(
						((String) ServletActionContext.getServletContext().getInitParameter("localDir")) + Case.FOLDER
								+ File.separator + mapName + File.separator + outputFilename);
				try {
					FileUtils.copyFile(
							new File(((String) ServletActionContext.getServletContext().getInitParameter("localDir"))
									+ ActiveDocument.FOLDER + File.separator + filename),
							inputFile);
					FileUtils.copyFile(
							new File(((String) ServletActionContext.getServletContext().getInitParameter("localDir"))
									+ ActiveDocument.FOLDER + File.separator + outputFilename),
							outputFile);
					UploadCaseAction uc = new UploadCaseAction();
					uc.setMapName(mapName);
					uc.setCaseName(caseName);
					uc.setInputFile(inputFile);
					uc.setOutputFile(outputFile);
					uc.setOutputFilePattern(outputFilePattern);
					uc.setRecords(records);
					return uc.execute();
				} catch (IOException e) {
					e.printStackTrace();
					return ERROR;
				}
			}
		}
		return ERROR;
	}
}
