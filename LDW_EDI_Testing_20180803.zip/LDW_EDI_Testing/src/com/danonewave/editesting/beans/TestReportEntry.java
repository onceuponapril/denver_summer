package com.danonewave.editesting.beans;

public class TestReportEntry {
	private String caseName;
	private ADFile[] inputFiles;
	private ADFile[] outputFiles;
	private String status;
	
	public TestReportEntry(String caseName, ADFile[] inputFiles, ADFile[] outputFiles, String status){
		this.caseName = caseName;
		this.inputFiles = inputFiles;
		this.outputFiles = outputFiles;
		this.status = status;
	}
	
	public String getCaseName() {
		return caseName;
	}
	public void setCaseName(String caseName) {
		this.caseName = caseName;
	}
	public ADFile[] getInputFiles() {
		return inputFiles;
	}
	public void setInputFile(ADFile[] inputFiles) {
		this.inputFiles = inputFiles;
	}
	public ADFile[] getOutputFiles() {
		return outputFiles;
	}
	public void setOutputFile(ADFile[] outputFiles) {
		this.outputFiles = outputFiles;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
