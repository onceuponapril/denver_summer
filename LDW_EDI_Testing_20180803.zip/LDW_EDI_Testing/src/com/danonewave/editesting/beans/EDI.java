package com.danonewave.editesting.beans;

public class EDI {
	private String sender;
	private String receiver;
	private String transaction;
	private String version;
	private String functionalGroup;

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getFunctionalGroup() {
		return functionalGroup;
	}

	public void setFunctionalGroup(String functionalGroup) {
		this.functionalGroup = functionalGroup;
	}

}
