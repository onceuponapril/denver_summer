package com.danonewave.editesting.actions.activedocument;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;


import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.ActiveDocument;
import com.opensymphony.xwork2.ActionSupport;

public class DownloadAction extends ActionSupport{
	private static final long serialVersionUID = -5076082739558586082L;
	private String fileName;
	private long contentLength;
	private InputStream fileInputStream;
	
	
	public String getFileName(){
		return fileName;
	}
	
	public void setFileName(String fileName){
		this.fileName = fileName;
	}
	
	public InputStream getFileInputStream() {
		return fileInputStream;
	}
	
	 public long getContentLength() {
	        return contentLength;
	    } 
    
	public String execute() throws Exception {
		File file = new File(((String) ServletActionContext.getServletContext().getInitParameter("localDir")) + ActiveDocument.FOLDER + File.separator + fileName);
	    fileInputStream = new FileInputStream(file);
	    contentLength = file.length();
	    return SUCCESS;
	}

}
