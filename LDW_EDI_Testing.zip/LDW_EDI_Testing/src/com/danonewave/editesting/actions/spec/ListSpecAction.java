package com.danonewave.editesting.actions.spec;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.Spec;
import com.opensymphony.xwork2.ActionSupport;

public class ListSpecAction extends ActionSupport {
	private static final long serialVersionUID = -2652400110649284772L;
	private List<Spec> specList;

	public List<Spec> getSpecList() {
		return specList;
	}

	public String execute() throws Exception {
		specList = new ArrayList<Spec>();
		String specDir = ((String) ServletActionContext.getServletContext().getInitParameter("localDir")) + Spec.FOLDER
				+ File.separator;

		for (String filename : new File(specDir).list(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String filename) {
				if (filename.endsWith(".xls") || filename.endsWith(".xlsx") || filename.endsWith(".xlsm")) {
					return true;
				}
				return false;
			}
		})) {
			int firstIndex = filename.indexOf("_");
			int secondIndex = filename.lastIndexOf(".");
			String mapName = filename.substring(0, firstIndex);
			String specVersion = filename.substring(firstIndex + 1, secondIndex);

			Spec spec = new Spec(mapName, specVersion, filename);
			specList.add(spec);
		}
		return SUCCESS;
	}
}
