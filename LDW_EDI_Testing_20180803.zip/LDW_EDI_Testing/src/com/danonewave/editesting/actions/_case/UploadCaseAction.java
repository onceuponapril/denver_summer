package com.danonewave.editesting.actions._case;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.danonewave.editesting.beans.Case;

public class UploadCaseAction extends ActionSupport {
	private static final long serialVersionUID = -7762636061033340769L;
	private String mapName;
	private String caseName;
	private File inputFile;
	private File outputFile;
	private String outputFilePattern;
	private String records;

	public String getMapName() {
		return mapName;
	}

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public void setCaseName(String caseName) {
		this.caseName = caseName;
	}

	public void setInputFile(File inputFile) {
		this.inputFile = inputFile;
	}

	public void setInputFileContentType(String inputFileContentType) {
	}

	public void setInputFileFileName(String inputFileFileName) {
	}

	public void setOutputFile(File outputFile) {
		this.outputFile = outputFile;
	}
	public void setOutputFileContentType(String outputFileContentType) {
	}

	public void setOutputFileFileName(String outputFileFileName) {
	}

	public void setOutputFilePattern(String outputFilePattern) {
		this.outputFilePattern = outputFilePattern;
	}
	
	public void setRecords(String records) {
		this.records = records;
	}


	public String execute() throws IOException {
		String caseDir = ((String) ServletActionContext.getServletContext().getInitParameter("localDir")) + Case.FOLDER
				+ File.separator + mapName + File.separator;
		inputFile.renameTo(new File(caseDir + caseName + "_input.txt"));
		outputFile.renameTo(new File(caseDir + caseName + "_output.txt"));

		PrintWriter writer = null;
		try {
			Properties properties = new Properties();
			properties.setProperty(Case.KEY_PATTERN, outputFilePattern);
			properties.setProperty(Case.KEY_RECORDS, records);
			writer = new PrintWriter(caseDir + caseName + ".properties");
			properties.store(writer, null);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (writer != null) {
				writer.close();
			}
		}
		return SUCCESS;
	}
}
