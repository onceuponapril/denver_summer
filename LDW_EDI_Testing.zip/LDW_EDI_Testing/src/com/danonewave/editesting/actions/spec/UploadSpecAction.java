package com.danonewave.editesting.actions.spec;

import java.io.File;

import java.io.IOException;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

import com.danonewave.editesting.beans.Spec;

public class UploadSpecAction extends ActionSupport {
	private static final long serialVersionUID = -7762636061033340769L;
	private String mapName;
	private String specVersion;
	private File specFile;
	private String specFileFileName;

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public void setSpecFile(File specFile) {
		this.specFile = specFile;
	}

	public void setSpecFileContentType(String specFileContentType) {
	}

	public void setSpecFileFileName(String specFileFileName) {
		this.specFileFileName = specFileFileName;
	}

	public String execute() throws IOException {
		String specDir = ((String) ServletActionContext.getServletContext().getInitParameter("localDir")) + Spec.FOLDER
				+ File.separator;
		String path = specDir + mapName + "_" + specVersion
				+ specFileFileName.substring(specFileFileName.lastIndexOf('.'));
		File newSpec = new File(path);
		specFile.renameTo(newSpec);

		return SUCCESS;
	}
}
