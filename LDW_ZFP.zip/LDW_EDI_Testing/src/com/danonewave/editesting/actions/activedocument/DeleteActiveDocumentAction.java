package com.danonewave.editesting.actions.activedocument;

import java.io.File;
import java.io.FilenameFilter;


import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.ActiveDocument;
import com.opensymphony.xwork2.ActionSupport;

public class DeleteActiveDocumentAction extends ActionSupport{
	private static final long serialVersionUID = -774398478250246964L;
	private String timestamp;
	
	public void setTimestamp(String timestamp){
		this.timestamp = timestamp;
	}
	
	@Override
	public String execute() throws Exception {
		File target2Dir = new File((ServletActionContext.getServletContext().getInitParameter("localDir")) + ActiveDocument.FOLDER );
		for (String filename : target2Dir.list(new FilenameFilter(){

			@Override
			public boolean accept(File dir, String name) {
				if (name.startsWith(timestamp)){
					return true;
				}
				return false;
			}})){
			new File(target2Dir.getAbsolutePath() + File.separator + filename).delete();
		}
	    return SUCCESS;
	}

}
