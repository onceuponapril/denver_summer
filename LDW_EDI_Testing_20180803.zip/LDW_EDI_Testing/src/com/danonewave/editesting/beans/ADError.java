package com.danonewave.editesting.beans;

public class ADError {
	private String errorCode;
	private String errorStatus;
	private String errorDesc;
	private String errorMsg;

	public ADError(String errorCode, String errorStatus, String errorDesc, String errorMsg) {
		this.errorCode = errorCode;
		this.errorStatus = errorStatus;
		this.errorDesc = errorDesc;
		this.errorMsg = errorMsg;

	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorStatus() {
		return errorStatus;
	}

	public void setErrorStatus(String errorStatus) {
		this.errorStatus = errorStatus;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
}
