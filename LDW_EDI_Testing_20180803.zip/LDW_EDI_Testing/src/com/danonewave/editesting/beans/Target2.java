package com.danonewave.editesting.beans;

import java.util.Date;

public class Target2 implements Comparable<Target2> {
	public final static String FOLDER = "Target2";
	
	private Date timestamp;
	private String mapName;
	private String ediFile;
	private String emailFile;
	private String result;

	public Target2(Date timestamp, String mapName, String ediFile, String emailFile, String result) {
		this.timestamp = timestamp;
		this.mapName = mapName;
		this.ediFile = ediFile;
		this.emailFile = emailFile;
		this.result = result;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public String getMapName() {
		return mapName;
	}

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public String getEdiFile() {
		return ediFile;
	}

	public void setEdiFile(String ediFile) {
		this.ediFile = ediFile;
	}

	public String getEmailFile() {
		return emailFile;
	}

	public void setEmailFile(String emailFile) {
		this.emailFile = emailFile;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	@Override
	public int compareTo(Target2 target2) {
		return target2.timestamp.compareTo(this.timestamp);
	}
	
	

}
