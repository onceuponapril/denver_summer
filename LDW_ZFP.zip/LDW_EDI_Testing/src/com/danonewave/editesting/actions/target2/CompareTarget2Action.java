package com.danonewave.editesting.actions.target2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;

import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.Target2;
import com.opensymphony.xwork2.ActionSupport;

public class CompareTarget2Action extends ActionSupport {
	private static final long serialVersionUID = 333870148418312903L;
	private String mapName;
	private File ediFile;
	private File emailFile;
	boolean startRead=false;

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public void setEdiFile(File ediFile) {
		this.ediFile = ediFile;
	}

	public void setEmailFile(File emailFile) {
		this.emailFile = emailFile;
	}

	public void setEdiFileFileName(String ediFileFileName) {
	}

	public void setEdiFileContentType(String ediFileContentType) {
	}

	public void setEmailFileFileName(String emailFileFileName) {
	}

	public void setEmailFileContentType(String emailFileContentType) {
	}

	@Override
	public String execute() {
		FileReader ediFileReader = null;
		FileReader emailFileReader = null;

		String message = null;

		String timestamp = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
		String target2Dir = (ServletActionContext.getServletContext().getInitParameter("localDir"))
				+ Target2.FOLDER + File.separator;

		try {

			ediFileReader = new FileReader(saveEdiContent(timestamp, target2Dir));
			emailFileReader = new FileReader(saveEmailContent(timestamp, target2Dir));
			BufferedReader ediBufferedReader = new BufferedReader(ediFileReader);
			BufferedReader emailBufferedReader = new BufferedReader(emailFileReader);

			String ediLine;
			String emailLine;
			int ediLineNum = 0;
			String fieldDelimiter = "\\*";
			// String compositeDelimiter = "^";
			String recordDelimiter = "~";
			message = "Success";

			loop_edi_lines: while ((ediLine = ediBufferedReader.readLine()) != null) {
				ediLineNum = ediLineNum + 1;
				if (ediLineNum == 1) {
					fieldDelimiter = ediLine.substring(ediLine.length() - 3, ediLine.length() - 2);
					// compositeDelimiter =
					// ediLine.substring(ediLine.length() - 2,
					// ediLine.length() - 1);
					recordDelimiter = ediLine.substring(ediLine.length() - 1, ediLine.length());
				}
				String[] ediFields = ediLine.split(Pattern.quote(fieldDelimiter));
				String ediSegment = ediFields[0];
				switch (ediSegment) {
				case "ISA":
				case "GS":
				case "ST":
				case "SE":
				case "GE":
				case "IEA":
				case "":
					// ignore
					break;
				default:
					loop_edi_fields: for (int i = 1; i < ediFields.length; i++) {
						String ediField = (i == ediFields.length - 1) ? ediFields[i].replace(recordDelimiter, "")
								: ediFields[i];
						if (!ediField.isEmpty()) {
							String ediFieldPosition = getPosition(i);
							emailLine = emailBufferedReader.readLine();
							
							while ((emailLine = emailBufferedReader.readLine()) != null) {
								while(!startRead) {
									if(emailLine.trim().length() == 0){
										startRead=true;
									}
									continue;
									
								}
								
								
								if (emailLine.length() > 50 && emailLine.charAt(50) == '=') {
									String[] emailSegments = emailLine.substring(0, 15).trim().split("_");
									String emailSegment = emailSegments[0];
									String emailField = emailLine.substring(51).trim();
									String emailFieldPosition;
									if (emailSegments.length == 3) {
										emailFieldPosition = emailSegments[1];
									} else {
										emailFieldPosition = emailSegments[2];
									}

									if (ediSegment.equals(emailSegment) && ediFieldPosition.equals(emailFieldPosition)
											&& ediField.equals(emailField)) {
										continue loop_edi_fields;
									}
								}
							}

							message = "Not found matched EDI field in Email: " + ediSegment + "_" + ediFieldPosition
									+ " at line " + ediLineNum;
							break loop_edi_lines;
						}
					}
				}
			}

		} catch (Exception e) {
			message = e.toString();
		} finally {
			if (ediFileReader != null) {
				try {
					ediFileReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			if (emailFileReader != null) {
				try {
					emailFileReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		PrintWriter resultFileWriter = null;
		try {
			resultFileWriter = new PrintWriter(target2Dir + timestamp + "_" + mapName + "_result.txt");
			resultFileWriter.write(message);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (resultFileWriter != null) {
				resultFileWriter.close();
			}
		}

		return SUCCESS;
	}

	private static String getPosition(int index) {
		if (index < 10) {
			return "0" + index;
		} else {
			return String.valueOf(index);
		}
	}

	private String saveEdiContent(String timestamp, String dir) {
		String path = dir + timestamp + "_" + mapName + "_edi.txt";
		File newEdi = new File(path);
		ediFile.renameTo(newEdi);
		return path;
	}

	private String saveEmailContent(String timestamp, String dir) {
		String path = dir + timestamp + "_" + mapName + "_email.txt";
		File newEmail = new File(path);
		emailFile.renameTo(newEmail);
		return path;
	}

}
