package com.danonewave.editesting.beans;

public class ErrorFile {
	private String errorCode;
	private String errorStatus;
	private String trackingTime;
	private String errorDesc;
	private String errorMsg;
	
	

	public ErrorFile(String errorCode, String errorStatus, String errorDesc,String trackingTime,String errorMsg) {
		this.errorCode = errorCode;
		this.errorStatus = errorStatus;
		this.trackingTime = trackingTime;
		this.errorDesc = errorDesc;
		this.errorMsg = errorMsg;

	}

	public String getErrorCode() {
		return errorCode;
	}



	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}



	public String getErrorStatus() {
		return errorStatus;
	}



	public void setErrorStatus(String errorStatus) {
		this.errorStatus = errorStatus;
	}



	public String getTrackingTime() {
		return trackingTime;
	}



	public void setTrackingTime(String trackingTime) {
		this.trackingTime = trackingTime;
	}



	public String getErrorDesc() {
		return errorDesc;
	}



	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}



	public String getErrorMsg() {
		return errorMsg;
	}



	public void setErrorMsg(String errorMsg) {
		this.errorMsg=errorMsg;
		 ;
	}
}
	