package com.danonewave.editesting.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.ProtocolException;
import org.apache.http.client.RedirectStrategy;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.SystemDefaultRoutePlanner;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.danonewave.editesting.beans.ADFile;
import com.danonewave.editesting.beans.ErrorFile;
import com.danonewave.editesting.beans.Session;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TradingGridUtil {
	public static CloseableHttpClient generateHttpClient(Hashtable<String, String> cookies) {
		HttpClientBuilder builder = HttpClients.custom();
		builder.setRedirectStrategy(new RedirectStrategy() {
			@Override
			public HttpUriRequest getRedirect(HttpRequest request, HttpResponse response, HttpContext context)
					throws ProtocolException {
				String location = null;
				handleSetCookie(cookies, response);
				for (Header header : response.getAllHeaders()) {
					if (header.getName().equals("Location")) {
						if (header.getValue().startsWith("http")) {
							location = header.getValue();
						} else {
							location = "https://betagrid.gxs.com" + header.getValue();
						}
					}
				}
				HttpGet redirectRequest = new HttpGet(location);
				redirectRequest.setHeader("Cookie", generateCookie(cookies));
				return redirectRequest;
			}

			@Override
			public boolean isRedirected(HttpRequest request, HttpResponse response, HttpContext context)
					throws ProtocolException {
				if (response.getStatusLine().getStatusCode() == 302
						|| response.getStatusLine().getStatusCode() == 301) {
					return true;
				}
				return false;
			}
		});
		builder.setRoutePlanner(new SystemDefaultRoutePlanner(null));
		builder.setDefaultRequestConfig(RequestConfig.custom().setCookieSpec(CookieSpecs.STANDARD).build());
		return builder.build();
	}

	/*
	 * public static void main(String[] args) throws Exception {
	 * Hashtable<String, String> cookies = new Hashtable<String, String>();
	 * HttpClientBuilder builder = HttpClients.custom();
	 * builder.setRedirectStrategy(new RedirectStrategy() {
	 * 
	 * @Override public HttpUriRequest getRedirect(HttpRequest request,
	 * HttpResponse response, HttpContext context) throws ProtocolException {
	 * String location = null; handleSetCookie(cookies, response); for (Header
	 * header : response.getAllHeaders()) { if
	 * (header.getName().equals("Location")) { if
	 * (header.getValue().startsWith("http")) { location = header.getValue(); }
	 * else { location = "https://betagrid.gxs.com" + header.getValue(); } } }
	 * HttpGet redirectRequest = new HttpGet(location);
	 * redirectRequest.setHeader("Cookie", generateCookie(cookies)); return
	 * redirectRequest; }
	 * 
	 * @Override public boolean isRedirected(HttpRequest request, HttpResponse
	 * response, HttpContext context) throws ProtocolException { if
	 * (response.getStatusLine().getStatusCode() == 302 ||
	 * response.getStatusLine().getStatusCode() == 301) { return true; } return
	 * false; } });
	 * builder.setDefaultRequestConfig(RequestConfig.custom().setCookieSpec(
	 * CookieSpecs.STANDARD).build()); CloseableHttpClient httpclient =
	 * builder.build(); postLogin(httpclient,
	 * "xiaowei.wang@external.danone.com", "P@ssw0rdJune"); //
	 * postSearch(httpclient, cookies,getSearch(httpclient, cookies));
	 * 
	 * exportOutput(httpclient, cookies, getFile(httpclient, cookies,
	 * "F-37742768")); // while(true){ // getSearchResponse(httpclient,
	 * cookies); // // Thread.sleep(10000L); // } httpclient.close(); }
	 */
	public static void postLogin(CloseableHttpClient httpclient, String username, String password) throws Exception {
		HttpUriRequest request = RequestBuilder.post()
				.setUri(new URI("https://betagrid.gxs.com/portal/login/login.fcc")).addParameter("username", username)
				.addParameter("password", password).addParameter("domain", "$$domain$$")
				.addParameter("realm", "$$realm$$").addParameter("Submit", "Sign in").build();

		CloseableHttpResponse response = httpclient.execute(request);
		try {
			HttpEntity entity = response.getEntity();
			EntityUtils.consume(entity);
		} finally {
			response.close();
		}

	}

	public static void getSearch(CloseableHttpClient httpclient, Session session) throws Exception {
		HttpGet request = new HttpGet("https://betagrid.gxs.com/adweb/search/search.adw");
		request.setHeader("Cookie", generateCookie(session.getCookies()));
		CloseableHttpResponse response = httpclient.execute(request);
		try {
			HttpEntity entity = response.getEntity();
			handleSetCookie(session.getCookies(), response);
			String htmlString = EntityUtils.toString(entity);
			session.setState(HTMLUtil.retrieveState(htmlString));
			EntityUtils.consume(entity);
		} finally {
			response.close();
		}
	}

	public static void postSearchInboundByFG(CloseableHttpClient httpclient, Session session, String functionalGroup, String timestamp) throws Exception {
		Date date = new SimpleDateFormat("yyyyMMddHHmmssSSS").parse(timestamp);
		String dateFrom = new SimpleDateFormat("MMM-dd-yyyy HH:mm:ss").format(date);
		String dateTo = new SimpleDateFormat("MMM-dd-yyyy HH:mm:ss").format(new Date(date.getTime() + 300000L));

		HttpUriRequest request = RequestBuilder.post()
				.setUri(new URI("https://betagrid.gxs.com/adweb/search/search.adw"))
				.addParameter("javax.faces.ViewState", session.getState())
				.addParameter("javax.faces.partial.ajax", "true")
				.addParameter("javax.faces.partial.execute",
						"mainForm:dynaForm mainForm:dynaFormFile mainForm:dynaFormDoc mainForm:dynaFormIC")
				// .addParameter("javax.faces.partial.render", "")
				.addParameter("javax.faces.source", "mainForm:dynaFormDoc:submitForm")
				.addParameter("mainForm", "mainForm")
				.addParameter("mainForm:dynaForm:DATE_FROM:DATE_FROM_calendarInput", dateFrom)
				.addParameter("mainForm:dynaForm:DATE_TO:DATE_TO_calendarInput", dateTo)
				.addParameter("mainForm:dynaForm:DIRECTION:sel2_focus", "")
				.addParameter("mainForm:dynaForm:DIRECTION:sel2_input", "received")
				.addParameter("mainForm:dynaForm:DOCEXTENDED:hiddenDocExtended", "true")
				.addParameter("mainForm:dynaForm:EXTENDED:hiddenExtended", "true")
				.addParameter("mainForm:dynaForm:EXTENDED:hiddenValidateDefaultKeys", "true")
				.addParameter("mainForm:dynaForm:GXS_REF_NO:txt1", "")
				.addParameter("mainForm:dynaForm:LEVEL_SELECTOR:search_level", "DOCUMENT")
				.addParameter("mainForm:dynaForm:MAILBOX:MAILBOX_focus", "")
				.addParameter("mainForm:dynaForm:MAILBOX:MAILBOX_input", "")
				.addParameter("mainForm:dynaForm:PARTNER_NAME:autocompl_input", "")
				.addParameter("mainForm:dynaForm:RECEIVER_EDI_ADDRESS:autocompl2_input", "")
				.addParameter("mainForm:dynaForm:RELDATE:fromDays", "3")
				.addParameter("mainForm:dynaForm:RELDATE:fromTime", "00:00:00")
				.addParameter("mainForm:dynaForm:RELDATE:selRelative_editableInput", "Tomorrow")
				.addParameter("mainForm:dynaForm:RELDATE:selRelative_focus", "")
				.addParameter("mainForm:dynaForm:RELDATE:selRelative_input", "-1")
				.addParameter("mainForm:dynaForm:RELDATE:toTime", "00:00:00")
				.addParameter("mainForm:dynaForm:SENDER_EDI_ADDRESS:autocompl1_input", "")
				.addParameter("mainForm:dynaForm:r3c2reg:date_option", "specific")
				.addParameter("mainForm:dynaFormDoc:DOC_PRIMARY_KEY:DOC_PRIMARY_KEY_input", "")
				.addParameter("mainForm:dynaFormDoc:DOC_PRIMARY_KEY_VALUE:DOC_PRIMARY_KEY_VALUE", "")
				.addParameter("mainForm:dynaFormDoc:DOC_STATUS:DOC_STATUS_focus", "")
				.addParameter("mainForm:dynaFormDoc:DOC_STATUS:DOC_STATUS_input", "all")
				.addParameter("mainForm:dynaFormDoc:DOC_TYPE:DOC_TYPE", "")
				.addParameter("mainForm:dynaFormDoc:FG_CONTROL_NO:FG_CONTROL_NO", "")
				.addParameter("mainForm:dynaFormDoc:FG_OWNER_ADDRESS:FG_OWNER_ADDRESS", "")
				.addParameter("mainForm:dynaFormDoc:FG_TYPE:FG_TYPE", functionalGroup)
				.addParameter("mainForm:dynaFormDoc:INV_DOWNLOAD_STATUS:INV_DOWNLOAD_STATUS_focus", "")
				.addParameter("mainForm:dynaFormDoc:INV_DOWNLOAD_STATUS:INV_DOWNLOAD_STATUS_input", "")
				.addParameter("mainForm:dynaFormDoc:INV_STATUS:INV_STATUS_focus", "")
				.addParameter("mainForm:dynaFormDoc:INV_STATUS:INV_STATUS_input", "")
				.addParameter("mainForm:dynaFormDoc:KEY_OPERATOR0:KEY_OPERATOR0_focus", "")
				.addParameter("mainForm:dynaFormDoc:KEY_OPERATOR0:KEY_OPERATOR0_input", "eq")
				.addParameter("mainForm:dynaFormDoc:KEY_OPERATOR1:KEY_OPERATOR1_focus", "")
				.addParameter("mainForm:dynaFormDoc:KEY_OPERATOR0:KEY_OPERATOR1_input", "eq")
				.addParameter("mainForm:dynaFormDoc:KEY_OPERATOR0:KEY_OPERATOR2_focus", "")
				.addParameter("mainForm:dynaFormDoc:KEY_OPERATOR0:KEY_OPERATOR2_input", "eq")
				.addParameter("mainForm:dynaFormDoc:KEY_OPERATOR1:KEY_OPERATOR3_focus", "")
				.addParameter("mainForm:dynaFormDoc:KEY_OPERATOR0:KEY_OPERATOR3_input", "eq")
				.addParameter("mainForm:dynaFormDoc:KEY_OPERATOR1:KEY_OPERATOR4_focus", "")
				.addParameter("mainForm:dynaFormDoc:KEY_OPERATOR0:KEY_OPERATOR4_input", "eq")
				.addParameter("mainForm:dynaFormDoc:KEY_OPERATOR_PRIMARY:KEY_OPERATOR_PRIMARY_focus", "")
				.addParameter("mainForm:dynaFormDoc:KEY_OPERATOR_PRIMARY:KEY_OPERATOR_PRIMARY_input", "eq")
				.addParameter("mainForm:dynaFormDoc:LEGAL_NAME:LEGAL_NAME", "")
				.addParameter("mainForm:dynaFormDoc:LEGAL_PARTNER_NAME:LEGAL_PARTNER_NAME", "")
				.addParameter("mainForm:dynaFormDoc:SKEY0:SKEY0_input", "")
				.addParameter("mainForm:dynaFormDoc:SKEY0:SKEY1_input", "")
				.addParameter("mainForm:dynaFormDoc:SKEY0:SKEY2_input", "")
				.addParameter("mainForm:dynaFormDoc:SKEY0:SKEY3_input", "")
				.addParameter("mainForm:dynaFormDoc:SKEY0:SKEY4_input", "")
				.addParameter("mainForm:dynaFormDoc:SKEY0:SKEY5_input", "")
				.addParameter("mainForm:dynaFormDoc:SKEY0:SKEY6_input", "")
				.addParameter("mainForm:dynaFormDoc:SKEY0:SKEY7_input", "")
				.addParameter("mainForm:dynaFormDoc:SKEY0:SKEY8_input", "")
				.addParameter("mainForm:dynaFormDoc:SKEY0:SKEY9_input", "")
				.addParameter("mainForm:dynaFormDoc:SKEY0:SKEY10_input", "")
				.addParameter("mainForm:dynaFormDoc:SKEY0:SKEY11_input", "")
				.addParameter("mainForm:dynaFormDoc:SKValue1:SKValue0", "")
				.addParameter("mainForm:dynaFormDoc:SKValue1:SKValue1", "")
				.addParameter("mainForm:dynaFormDoc:SKValue1:SKValue2", "")
				.addParameter("mainForm:dynaFormDoc:SKValue1:SKValue3", "")
				.addParameter("mainForm:dynaFormDoc:SKValue1:SKValue4", "")
				.addParameter("mainForm:dynaFormDoc:submitForm", "mainForm:dynaFormDoc:submitForm")
				.addParameter("mainForm:dynaFormFile:APRF:APRF", "")
				.addParameter("mainForm:dynaFormFile:COMMUNICATION_TYPE:COMMUNICATION_TYPE_focus", "")
				.addParameter("mainForm:dynaFormFile:COMMUNICATION_TYPE:COMMUNICATION_TYPE_input", "")
				.addParameter("mainForm:dynaFormFile:FILE_NAME:FILE_NAME", "")
				.addParameter("mainForm:dynaFormFile:FILE_STATUS:FILE_STATUS_focus", "")
				.addParameter("mainForm:dynaFormFile:FILE_STATUS:FILE_STATUS_input", "all")
				.addParameter("mainForm:dynaFormFile:FILE_TRANSLATION_SESSION:FILE_TRANSLATION_SESSION", "")
				.addParameter("mainForm:dynaFormFile:ILOG:ILOG", "")
				.addParameter("mainForm:dynaFormFile:MAILBAG_NUMBER:MAILBAG_NUMBER", "")
				.addParameter("mainForm:dynaFormFile:SKEY0:SKEY0_input", "")
				.addParameter("mainForm:dynaFormFile:SKEY1:SKEY1_input", "")
				.addParameter("mainForm:dynaFormFile:SKEY2:SKEY2_input", "")
				.addParameter("mainForm:dynaFormFile:SKEY3:SKEY3_input", "")
				.addParameter("mainForm:dynaFormFile:SKEY4:SKEY4_input", "")
				.addParameter("mainForm:dynaFormFile:SKValue1:SKValue0", "")
				.addParameter("mainForm:dynaFormFile:SKValue1:SKValue1", "")
				.addParameter("mainForm:dynaFormFile:SKValue1:SKValue2", "")
				.addParameter("mainForm:dynaFormFile:SKValue1:SKValue3", "")
				.addParameter("mainForm:dynaFormFile:SKValue1:SKValue4", "")
				.addParameter("mainForm:dynaFormFile:SNRF:SNRF", "")
				.addParameter("mainForm:dynaFormFile:SRV_REF:SRV_REF", "")
				.addParameter("mainForm:dynaFormIC:IC_CONTROL_NO:IC_CONTROL_NO", "")
				.addParameter("mainForm:dynaFormIC:PRODUCTION_TEST_FLAG:PRODUCTION_TEST_FLAG_focus", "")
				.addParameter("mainForm:dynaFormIC:PRODUCTION_TEST_FLAG:PRODUCTION_TEST_FLAG_input", "")
				.addParameter("mainForm:hiddenKeyPreference", "").addParameter("mainForm:hiddenSearchDefaults", "{}")
				.addParameter("mainForm:hiddenSuspendDefaults", "false")
				.addParameter("mainForm:hiddenUnlimitedSearch", "false")
				.addParameter("mainForm:hiddenWSQueryResults_ma", "")
				.addParameter("mainForm:hiddenWSQueryResults_pa", "")
				.addParameter("mainForm:hiddenWSQueryResults_pn", "").addParameter("mainForm:j_idt552_focus", "")
				.addParameter("mainForm:j_idt552_input", "eq").addParameter("mainForm:j_idt569_focus", "")
				.addParameter("mainForm:j_idt569_input", "eq").addParameter("mainForm:j_idt587_focus", "")
				.addParameter("mainForm:j_idt587_input", "eq").addParameter("mainForm:j_idt605_focus", "")
				.addParameter("mainForm:j_idt605_input", "eq").addParameter("mainForm:j_idt623_focus", "")
				.addParameter("mainForm:j_idt623_input", "eq").addParameter("mainForm:j_idt641_focus", "")
				.addParameter("mainForm:j_idt641_input", "eq").addParameter("mainForm:keyinteractionname_input", "")
				.addParameter("mainForm:ma:auto-results_input", "").addParameter("mainForm:ma:auto_input", "")
				.addParameter("mainForm:ma:includeExclude", "include")
				.addParameter("mainForm:pa:auto-results_input", "").addParameter("mainForm:pa:auto_input", "")
				.addParameter("mainForm:pa:includeExclude", "include")
				.addParameter("mainForm:pn:auto-results_input", "").addParameter("mainForm:pn:auto_input", "")
				.addParameter("mainForm:pn:includeExclude", "include").addParameter("mainForm:primary0", "0")
				.addParameter("mainForm:primary1", "1").addParameter("mainForm:primary2", "2")
				.addParameter("mainForm:primary3", "3").addParameter("mainForm:primary4", "4")
				.addParameter("mainForm:primary5", "5").addParameter("mainForm:updatedJSONKeyString", "").build();
		request.setHeader("Cookie", generateCookie(session.getCookies()));
		CloseableHttpResponse response = httpclient.execute(request);
		try {
			HttpEntity entity = response.getEntity();
			handleSetCookie(session.getCookies(), response);
//			 InputStream is = entity.getContent();
//			 String filePath =
//			 "/Users/fanpanzeng/Documents/LDW_EDI_Testing/postsearch.xml";
//			 FileOutputStream fos = new FileOutputStream(new File(filePath));
//			 int inByte;
//			 while ((inByte = is.read()) != -1)
//			 fos.write(inByte);
//			 is.close();
//			 fos.close();
			EntityUtils.consume(entity);
		} finally {
			response.close();
		}
	}

	public static void getSearchResponse(CloseableHttpClient httpclient, Session session) throws Exception {
		HttpGet request = new HttpGet("https://betagrid.gxs.com/adweb/search/search_response.adw");
		request.setHeader("Cookie", generateCookie(session.getCookies()));
		CloseableHttpResponse response = httpclient.execute(request);
		try {
			HttpEntity entity = response.getEntity();
			handleSetCookie(session.getCookies(), response);
			session.setActiveDocuments(HTMLUtil.retrieveADFromQueryResponse(EntityUtils.toString(entity)));
			EntityUtils.consume(entity);
		} finally {
			response.close();
		}
	}

	public static void getFile(CloseableHttpClient httpclient, Session session) throws Exception {
		HttpGet request = new HttpGet(
				"https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw?fileId=" + session.getActiveDocuments()[0]
						+ "&processId=" + session.getActiveDocuments()[0] + "&contentType=FILE");
		request.setHeader("Cookie", generateCookie(session.getCookies()));
		CloseableHttpResponse response = httpclient.execute(request);
		try {
			HttpEntity entity = response.getEntity();
			handleSetCookie(session.getCookies(), response);
			String htmlString = EntityUtils.toString(entity);
			session.setState(HTMLUtil.retrieveState(htmlString));
			session.setTranslationStepId(HTMLUtil.retrieveTranslationStepId(htmlString));
			session.setErrorCount(HTMLUtil.errorCount(htmlString));          
			EntityUtils.consume(entity);
		} finally {
			response.close();
		}
	}
	
	
//	public static void getFileDetail(CloseableHttpClient httpclient, Session session) throws Exception {
//		HttpUriRequest request = RequestBuilder.post()
//				.setUri(new URI("https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw"))
//				.addParameter("javax.faces.partial.ajax","true")
//				.addParameter("javax.faces.source","documentTypeTabs:lifecycleForm:j_idt388")
//				.addParameter("javax.faces.partial.execute","@all")
//				.addParameter("javax.faces.partial.render", "documentTypeTabs:lifecycleForm:downloadGroup")
//				.addParameter("documentTypeTabs:lifecycleForm:j_idt388","documentTypeTabs:lifecycleForm:j_idt388")
//				.addParameter("documentTypeTabs:lifecycleForm", "documentTypeTabs:lifecycleForm")
//				.addParameter("documentTypeTabs:lifecycleForm:doc_header_info_panel_collapsed", "false")
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:processingStepTable_selection","")
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetURI","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetName","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetType","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileSetId","")
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileSetId","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileType","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputFileSetType","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileType","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputFileSetType","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentStepName","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileSetId", session.getTranslationStepId())
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileSetId", session.getTranslationStepId())
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileType","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileType","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_activeIndex","0")
//				.addParameter("documentTypeTabs:lifecycleForm:doc_lc_details_panel_collapsed","false")
//				.addParameter("javax.faces.ViewState", session.getState()).build();
//				request.setHeader("Origin", "https://betagrid.gxs.com");
//				request.setHeader("Upgrade-Insecure-Requests", "1");
//				request.setHeader("Content-Type", "text/xml;charset=UTF-8");
//				request.setHeader("User-Agent",
//						"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
//				request.setHeader("Faces-Request", "partial/ajax");
//				request.setHeader("X-Requested-With", "XMLHttpRequest");
//				request.setHeader("Accept",
//						"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
//				request.setHeader("Referer",
//						"https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw?fileId=" + session.getActiveDocuments()[0]
//								+ "&processId=" + session.getActiveDocuments()[0] + "&contentType=DOCUMENT");
//				request.setHeader("Accept-Encoding", "gzip, deflate, br");
//				request.setHeader("Accept-Language", "en-US,en;q=0.8");
//				request.setHeader("Cookie", generateCookie(session.getCookies()));
//				CloseableHttpResponse response = httpclient.execute(request);
//				try {
//					HttpEntity entity = response.getEntity();
//					handleSetCookie(session.getCookies(), response);
//					String htmlString = EntityUtils.toString(entity);
//					session.setState(HTMLUtil.retrieveState(htmlString));
//					session.setTranslationStepId(HTMLUtil.retrieveTranslationStepId(htmlString));
//					 InputStream is = entity.getContent();
//					 String filePath =
//					 "/Users/fanpanzeng/Documents/LDW_EDI_Testing/getfile.txt";
//					 FileOutputStream fos = new FileOutputStream(new File(filePath));
//					 int inByte=is.read();
////					 while ((inByte = is.read()) != -1)
//					 fos.write(inByte);
//					 is.close();
//					 fos.close();
//					EntityUtils.consume(entity);
//				} finally {
//					response.close();
//				}
//}
	
	public static void getInputOutputFiles(CloseableHttpClient httpclient, Session session) throws Exception {
		HttpUriRequest request = RequestBuilder.post()
				.setUri(new URI("https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw"))
				.addParameter("javax.faces.partial.ajax", "true")
				.addParameter("javax.faces.source",
						"documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputOutputsLink")
				.addParameter("javax.faces.partial.execute", "@all")
				.addParameter("javax.faces.partial.render",
						"documentTypeTabs:lifecycleForm:lifecycleDetailTabs:content-io-files")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputOutputsLink",
						"documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputOutputsLink")
				.addParameter("documentTypeTabs:lifecycleForm", "documentTypeTabs:lifecycleForm")
				.addParameter("documentTypeTabs:lifecycleForm:doc_header_info_panel_collapsed", "false")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:processingStepTable_selection", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetURI", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetName", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileSetId",
						session.getTranslationStepId())
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileSetId",
						session.getTranslationStepId())
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputFileSetType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputFileSetType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentStepName", "Translation")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileSetId",
						session.getTranslationStepId())
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileSetId",
						session.getTranslationStepId())
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileType",
						"")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_activeIndex", "0")
				.addParameter("documentTypeTabs:lifecycleForm:doc_lc_details_panel_collapsed", "false")
				.addParameter("javax.faces.ViewState", session.getState()).build();
		request.setHeader("Origin", "https://betagrid.gxs.com");
		request.setHeader("Upgrade-Insecure-Requests", "1");
		request.setHeader("Content-Type", "application/x-www-form-urlencoded");
		request.setHeader("User-Agent",
				"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
		request.setHeader("Faces-Request", "partial/ajax");
		request.setHeader("X-Requested-With", "XMLHttpRequest");
		request.setHeader("Accept",
				"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
		request.setHeader("Referer",
				"https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw?fileId=" + session.getActiveDocuments()[0]
						+ "&processId=" + session.getActiveDocuments()[0] + "&contentType=FILE");
		request.setHeader("Accept-Encoding", "gzip, deflate, br");
		request.setHeader("Accept-Language", "en-US,en;q=0.8");
		request.setHeader("Cookie", generateCookie(session.getCookies()));
		CloseableHttpResponse response = httpclient.execute(request);
		try {
			HttpEntity entity = response.getEntity();
			handleSetCookie(session.getCookies(), response);
//			 InputStream is = entity.getContent();
//			 String filePath =
//			 "/Users/fanpanzeng/Documents/LDW_EDI_Testing/getinputoutput.txt";
//			 FileOutputStream fos = new FileOutputStream(new File(filePath));
//			 int inByte;
//			 while ((inByte = is.read()) != -1)
//			 fos.write(inByte);
//			 is.close();
//			 fos.close();
			EntityUtils.consume(entity);
		} finally {
			response.close();
		}
	}

	
//	public static void 	ErrorCount(CloseableHttpClient httpclient, Session session) throws Exception{
//		HttpUriRequest request = RequestBuilder.post()
//				.setUri(new URI("https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw"))
//				.addParameter("javax.faces.partial.ajax", "true")
//				.addParameter("javax.faces.source", "documentTypeTabs:lifecycleForm:lifecycleDetailTabs")
//				.addParameter("javax.faces.partial.execute", "documentTypeTabs:lifecycleForm:lifecycleDetailTabs")
//				.addParameter("javax.faces.behavior.event", "tabChange")
//				.addParameter("javax.faces.partial.event", "tabChange")
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_newTab","documentTypeTabs:lifecycleForm:lifecycleDetailTabs:lifecycleDetailTab2")
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_tabindex", "1")
//				.addParameter("documentTypeTabs:lifecycleForm", "documentTypeTabs:lifecycleForm")
//				.addParameter("documentTypeTabs:lifecycleForm:doc_header_info_panel_collapsed", "false")
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:processingStepTable_selection","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetURI","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetName","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetType","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileSetId", session.getTranslationStepId())
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileSetId", session.getTranslationStepId())
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileType","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputFileSetType","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileType","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputFileSetType","" )
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentStepName", "Translation")
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileSetId",session.getTranslationStepId())
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileSetId",session.getTranslationStepId())
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileType","" )
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileType","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable_selection","") 
//				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_activeIndex", "1")
//				.addParameter("documentTypeTabs:lifecycleForm:doc_lc_details_panel_collapsed", "false")
//				.addParameter("javax.faces.ViewState",session.getState()).build();
//				request.setHeader("Origin", "https://betagrid.gxs.com");
//				request.setHeader("Upgrade-Insecure-Requests", "1");
//				request.setHeader("Content-Type", "application/x-www-form-urlencoded");
//				request.setHeader("User-Agent",
//						"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
//				request.setHeader("Faces-Request", "partial/ajax");
//				request.setHeader("X-Requested-With", "XMLHttpRequest");
//				request.setHeader("Accept",
//						"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
//				request.setHeader("Referer",
//						"https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw?fileId=" + session.getActiveDocuments()[0]
//								+ "&processId=" + session.getActiveDocuments()[0] + "&contentType=DOCUMENT");
//				request.setHeader("Accept-Encoding", "gzip, deflate, br");
//				request.setHeader("Accept-Language", "en-US,en;q=0.8");
//				request.setHeader("Cookie", generateCookie(session.getCookies()));
//				CloseableHttpResponse response = httpclient.execute(request);
//				try {
//					HttpEntity entity = response.getEntity();
//					handleSetCookie(session.getCookies(), response);
//					 InputStream is = entity.getContent();
//					 String filePath =
//					 "/Users/fanpanzeng/Documents/LDW_EDI_Testing/errorcount.txt";
//					 FileOutputStream fos = new FileOutputStream(new File(filePath));
//					 int inByte;
//					 while ((inByte = is.read()) != -1)
//					 fos.write(inByte);
//					 is.close();
//					 fos.close();
//					EntityUtils.consume(entity);
//				} finally {
//					response.close();
//				}
//			}
	
	
	
	public static void getError(CloseableHttpClient httpclient, Session session) throws Exception{
		HttpUriRequest request = RequestBuilder.post()
				.setUri(new URI("https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw"))
				.addParameter("javax.faces.partial.ajax", "true")
				.addParameter("javax.faces.source","documentTypeTabs:lifecycleForm:lifecycleDetailTabs")
				.addParameter("javax.faces.partial.execute","documentTypeTabs:lifecycleForm:lifecycleDetailTabs")
				.addParameter("javax.faces.partial.render", "documentTypeTabs:lifecycleForm:lifecycleDetailTabs")
				.addParameter("javax.faces.behavior.event","tabChange")
				.addParameter("javax.faces.partial.event", "tabChange")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_contentLoad", "true")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_newTab", "documentTypeTabs:lifecycleForm:lifecycleDetailTabs:lifecycleDetailTab2")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_tabindex", "1")
				.addParameter("documentTypeTabs:lifecycleForm","documentTypeTabs:lifecycleForm")
				.addParameter("documentTypeTabs:lifecycleForm:doc_header_info_panel_collapsed", "false")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:processingStepTable_selection","") 
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetURI","")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetName","") 
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetType","") 
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileSetId","") 
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileSetId","") 
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileType","") 
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputFileSetType","") 
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileType","") 
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputFileSetType","") 
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentStepName","")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileSetId", session.getTranslationStepId())
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileSetId", session.getTranslationStepId())
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileType","") 
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileType","") 
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_activeIndex", "1")
				.addParameter("documentTypeTabs:lifecycleForm:doc_lc_details_panel_collapsed", "false")
				.addParameter("javax.faces.ViewState", session.getState()).build();
				request.setHeader("Origin", "https://betagrid.gxs.com");
				request.setHeader("Upgrade-Insecure-Requests", "1");
				request.setHeader("Content-Type", "application/x-www-form-urlencoded");
				request.setHeader("User-Agent",
						"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
				request.setHeader("Faces-Request", "partial/ajax");
				request.setHeader("X-Requested-With", "XMLHttpRequest");
				request.setHeader("Accept",
						"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
				request.setHeader("Referer",
						"https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw?fileId=" + session.getActiveDocuments()[0]
								+ "&processId=" + session.getActiveDocuments()[0] + "&contentType=DOCUMENT");
				request.setHeader("Accept-Encoding", "gzip, deflate, br");
				request.setHeader("Accept-Language", "en-US,en;q=0.8");
				request.setHeader("Cookie", generateCookie(session.getCookies()));
				CloseableHttpResponse response = httpclient.execute(request);
				try {
					HttpEntity entity = response.getEntity();
					handleSetCookie(session.getCookies(), response);
//					 InputStream is = entity.getContent();
//					 String filePath =
//					 "/Users/fanpanzeng/Documents/LDW_EDI_Testing/errorpage.txt";
//					 FileOutputStream fos = new FileOutputStream(new File(filePath));
//					 int inByte;
//					 while ((inByte = is.read()) != -1)
//					 fos.write(inByte);
//					 is.close();
//					 fos.close();
					EntityUtils.consume(entity);
				} finally {
					response.close();
				}
			}
	
	public static void errorsDesc(CloseableHttpClient httpclient, Session session,ErrorFile errorFile) throws Exception{
					HttpUriRequest request = RequestBuilder.post()
					.setUri(new URI("https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw"))
					.addParameter("javax.faces.partial.ajax", "true")
					.addParameter("javax.faces.source","documentTypeTabs:lifecycleForm:lifecycleDetailTabs:j_idt519")
					.addParameter("javax.faces.partial.execute","@all")
					.addParameter("javax.faces.partial.render", "documentTypeTabs:lifecycleForm:lifecycleDetailTabs:myPanel")
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:j_idt519", "documentTypeTabs:lifecycleForm:lifecycleDetailTabs:j_idt519")	
					.addParameter("documentTypeTabs:lifecycleForm","documentTypeTabs:lifecycleForm")
					.addParameter("documentTypeTabs:lifecycleForm:doc_header_info_panel_collapsed", "false")
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:processingStepTable_selection", "")
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetURI", "")
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetName", "")
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetType", "")
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileSetId",
							session.getTranslationStepId())
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileSetId",
							session.getTranslationStepId())
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileType", "")
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputFileSetType", "")
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileType", "")
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputFileSetType", "")
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentStepName", "Translation")
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileSetId",
							session.getTranslationStepId())
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileSetId",
							session.getTranslationStepId())
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileType", "")
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileType","")
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable_selection","")
					.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_activeIndex", "1")
					.addParameter("documentTypeTabs:lifecycleForm:doc_lc_details_panel_collapsed", "false")
					.addParameter("javax.faces.ViewState", session.getState()).build();
			request.setHeader("Origin", "https://betagrid.gxs.com");
			request.setHeader("Upgrade-Insecure-Requests", "1");
			request.setHeader("Content-Type", "application/x-www-form-urlencoded");
			request.setHeader("User-Agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
			request.setHeader("Faces-Request", "partial/ajax");
			request.setHeader("X-Requested-With", "XMLHttpRequest");
			request.setHeader("Accept",
					"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
			request.setHeader("Referer",
					"https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw?fileId=" + session.getActiveDocuments()[0]
							+ "&processId=" + session.getActiveDocuments()[0] + "contentType=FILE");
			request.setHeader("Accept-Encoding", "gzip, deflate, br");
			request.setHeader("Accept-Language", "en-US,en;q=0.8");
			request.setHeader("Cookie", generateCookie(session.getCookies()));
			CloseableHttpResponse response = httpclient.execute(request);
			
				try {
					HttpEntity entity = response.getEntity();
					handleSetCookie(session.getCookies(), response);
					String xmlString = EntityUtils.toString(entity);
					String htmlString = XMLUtil.retrieveInputsOutputsTableHTML(xmlString);
					errorFile= HTMLUtil.retrieveErrorInfo(htmlString,errorFile);
//					 InputStream is = entity.getContent();
//					 System.out.println(is);
//					 String filePath =
//					 "/Users/fanpanzeng/Documents/LDW_EDI_Testing/geterror.txt";
//					 FileOutputStream fos = new FileOutputStream(new File(filePath));
//					 int inByte=is.read();
//					 while ((inByte = is.read()) != -1)
//					 fos.write(inByte);
//					 is.close();
//					 fos.close();
					EntityUtils.consume(entity);
				} finally {
					response.close();
				}
			}	
				

	public static void errorsMsg(CloseableHttpClient httpclient, Session session, ErrorFile errorFile) throws Exception{
		HttpUriRequest request = RequestBuilder.post()
		.setUri(new URI("https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw"))
		.addParameter("javax.faces.partial.ajax", "true")
		.addParameter("javax.faces.source",
				"documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable")
		.addParameter("javax.faces.partial.execute","documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable")
		.addParameter("javax.faces.partial.render",
				"documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable", "documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable_rowExpansion", "true")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable_expandedRowIndex","0")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable_encodeFeature", "true")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable_skipChildren", "true")
		.addHeader("documentTypeTabs:lifecycleForm","documentTypeTabs:lifecycleForm")
		.addParameter("documentTypeTabs:lifecycleForm:doc_header_info_panel_collapsed", "false")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:processingStepTable_selection", "")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetURI", "")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetName", "")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetType", "")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileSetId",
				"")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileSetId",
				"")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileType", "")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputFileSetType", "")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileType", "")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputFileSetType", "")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentStepName", "")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileSetId",
				session.getTranslationStepId())
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileSetId",
				session.getTranslationStepId())
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileType", "")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileType", "")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable_selection","")
		.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_activeIndex", "1")
		.addParameter("documentTypeTabs:lifecycleForm:doc_lc_details_panel_collapsed", "false")
		.addParameter("javax.faces.ViewState", session.getState()).build();
request.setHeader("Origin", "https://betagrid.gxs.com");
request.setHeader("Upgrade-Insecure-Requests", "1");
request.setHeader("Content-Type", "application/x-www-form-urlencoded");
request.setHeader("User-Agent",
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
request.setHeader("Faces-Request", "partial/ajax");
request.setHeader("X-Requested-With", "XMLHttpRequest");
request.setHeader("Accept",
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
request.setHeader("Referer",
		"https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw?fileId=" + session.getActiveDocuments()[0]
				+ "&processId=" + session.getActiveDocuments()[0] +"&contentType=DOCUMENT");
request.setHeader("Accept-Encoding", "gzip, deflate, br");
request.setHeader("Accept-Language", "en-US,en;q=0.8");
request.setHeader("Cookie", generateCookie(session.getCookies()));
CloseableHttpResponse response = httpclient.execute(request);

	try {
		HttpEntity entity = response.getEntity();
		handleSetCookie(session.getCookies(), response);
		String xmlString = EntityUtils.toString(entity);
		String htmlString = XMLUtil.retrieveInputsOutputsTableHTML(xmlString);
		errorFile= HTMLUtil.retrieveErrorMsg(htmlString,errorFile);
//		 InputStream is = entity.getContent();
//		 String filePath =
//		 "/Users/fanpanzeng/Documents/LDW_EDI_Testing/geterrormsg.txt";
//		 FileOutputStream fos = new FileOutputStream(new File(filePath));
//		 int inByte;
//		 while ((inByte = is.read()) != -1)
//		 fos.write(inByte);
//		 is.close();
//		 fos.close();
		EntityUtils.consume(entity);
	} finally {
		response.close();
	}
}			
			
	public static void errorsToXml(String activeDocumentDir,String timestamp,ErrorFile errorFile) throws ParserConfigurationException, TransformerException {
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		
	    Document doc = docBuilder.newDocument();
		Element rootElement = doc.createElement("Errors");
		doc.appendChild(rootElement);
		
		Element errorCode = doc.createElement("errorCode");
		errorCode.appendChild(doc.createTextNode(errorFile.getErrorCode()));
		rootElement.appendChild(errorCode);
		
		Element errorStatus = doc.createElement("errorStatus");
		errorStatus.appendChild(doc.createTextNode(errorFile.getErrorStatus()));
		rootElement.appendChild(errorStatus);

		Element trackingTime = doc.createElement("trackingTime");
		trackingTime.appendChild(doc.createTextNode(errorFile.getTrackingTime()));
		rootElement.appendChild(trackingTime);
		
		Element errorDesc = doc.createElement("errorDesc");
		errorDesc.appendChild(doc.createTextNode(errorFile.getErrorDesc()));
		rootElement.appendChild(errorDesc);
		
		Element errorMsg = doc.createElement("errorMsg");
		errorMsg.appendChild(doc.createTextNode(errorFile.getErrorMsg()));
		rootElement.appendChild(errorMsg);
		
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(activeDocumentDir+timestamp+"_errors.xml"));
		transformer.transform(source, result);
}
	
	public static void listInputFiles(CloseableHttpClient httpclient, Session session) throws Exception {
		HttpUriRequest request = RequestBuilder.post()
				.setUri(new URI("https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw"))
				.addParameter("javax.faces.partial.ajax", "true")
				.addParameter("javax.faces.source",
						"documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputOutputsRadio")
				.addParameter("javax.faces.partial.execute",
						"documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputOutputsRadio")
				.addParameter("javax.faces.partial.render",
						"documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable")
				.addParameter("javax.faces.behavior.event", "change")
				.addParameter("javax.faces.partial.event", "change")
				.addParameter("documentTypeTabs:lifecycleForm", "documentTypeTabs:lifecycleForm")
				.addParameter("documentTypeTabs:lifecycleForm:doc_header_info_panel_collapsed", "false")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:processingStepTable_selection", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetURI", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetName", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileSetId",
						session.getTranslationStepId())
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileSetId",
						session.getTranslationStepId())
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputFileSetType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputFileSetType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentStepName", "Translation")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileSetId",
						session.getTranslationStepId())
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileSetId",
						session.getTranslationStepId())
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileType",
						"")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputOutputsRadio", "inputs")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable:j_idt598:filter",
						"")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable:j_idt600:filter",
						"")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable_selection", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_activeIndex", "1")
				.addParameter("documentTypeTabs:lifecycleForm:doc_lc_details_panel_collapsed", "false")
				.addParameter("javax.faces.ViewState", session.getState()).build();
		request.setHeader("Origin", "https://betagrid.gxs.com");
		request.setHeader("Upgrade-Insecure-Requests", "1");
		request.setHeader("Content-Type", "application/x-www-form-urlencoded");
		request.setHeader("User-Agent",
				"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
		request.setHeader("Faces-Request", "partial/ajax");
		request.setHeader("X-Requested-With", "XMLHttpRequest");
		request.setHeader("Accept",
				"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
		request.setHeader("Referer",
				"https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw?fileId=" + session.getActiveDocuments()[0]
						+ "&processId=" + session.getActiveDocuments()[0] + "&contentType=FILE");
		request.setHeader("Accept-Encoding", "gzip, deflate, br");
		request.setHeader("Accept-Language", "en-US,en;q=0.8");
		request.setHeader("Cookie", generateCookie(session.getCookies()) + "primefaces.download=true;");
		CloseableHttpResponse response = httpclient.execute(request);
		try {
			HttpEntity entity = response.getEntity();
			handleSetCookie(session.getCookies(), response);
			String xmlString = EntityUtils.toString(entity);
			String htmlString = XMLUtil.retrieveInputsOutputsTableHTML(xmlString);
			ADFile[] inputs = HTMLUtil.retrieveInputsOutputs(htmlString);
			session.setInputs(inputs);
			EntityUtils.consume(entity);
		} finally {
			response.close();
		}
	}
	
	public static void listOutputFiles(CloseableHttpClient httpclient, Session session) throws Exception {
		HttpUriRequest request = RequestBuilder.post()
				.setUri(new URI("https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw"))
				.addParameter("javax.faces.partial.ajax", "true")
				.addParameter("javax.faces.source",
						"documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputOutputsRadio")
				.addParameter("javax.faces.partial.execute",
						"documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputOutputsRadio")
				.addParameter("javax.faces.partial.render",
						"documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable")
				.addParameter("javax.faces.behavior.event", "change")
				.addParameter("javax.faces.partial.event", "change")
				.addParameter("documentTypeTabs:lifecycleForm", "documentTypeTabs:lifecycleForm")
				.addParameter("documentTypeTabs:lifecycleForm:doc_header_info_panel_collapsed", "false")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:processingStepTable_selection", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetURI", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetName", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileSetId",
						session.getTranslationStepId())
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileSetId",
						session.getTranslationStepId())
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputFileSetType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputFileSetType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentStepName", "Translation")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileSetId",
						session.getTranslationStepId())
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileSetId",
						session.getTranslationStepId())
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileType",
						"")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputOutputsRadio", "outputs")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable:j_idt598:filter",
						"")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable:j_idt600:filter",
						"")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable_selection", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_activeIndex", "1")
				.addParameter("documentTypeTabs:lifecycleForm:doc_lc_details_panel_collapsed", "false")
				.addParameter("javax.faces.ViewState", session.getState()).build();
		request.setHeader("Origin", "https://betagrid.gxs.com");
		request.setHeader("Upgrade-Insecure-Requests", "1");
		request.setHeader("Content-Type", "application/x-www-form-urlencoded");
		request.setHeader("User-Agent",
				"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
		request.setHeader("Faces-Request", "partial/ajax");
		request.setHeader("X-Requested-With", "XMLHttpRequest");
		request.setHeader("Accept",
				"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
		request.setHeader("Referer",
				"https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw?fileId=" + session.getActiveDocuments()[0]
						+ "&processId=" + session.getActiveDocuments()[0] + "&contentType=FILE");
		request.setHeader("Accept-Encoding", "gzip, deflate, br");
		request.setHeader("Accept-Language", "en-US,en;q=0.8");
		request.setHeader("Cookie", generateCookie(session.getCookies()) + "primefaces.download=true;");
		CloseableHttpResponse response = httpclient.execute(request);
		try {
			HttpEntity entity = response.getEntity();
			handleSetCookie(session.getCookies(), response);
			String xmlString = EntityUtils.toString(entity);
			String htmlString = XMLUtil.retrieveInputsOutputsTableHTML(xmlString);
			ADFile[] outputs = HTMLUtil.retrieveInputsOutputs(htmlString);
			session.setOutputs(outputs);
			EntityUtils.consume(entity);
		} finally {
			response.close();
		}
	}

	public static void exportFileStep1(CloseableHttpClient httpclient, Session session, ADFile adFile)
			throws Exception {
		HttpUriRequest request = RequestBuilder.post()
				.setUri(new URI("https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw"))
				.addParameter("javax.faces.partial.ajax", "true")
				.addParameter("javax.faces.source", "documentTypeTabs:bulkDownloadForm:btnContinue")
				.addParameter("javax.faces.partial.execute", "documentTypeTabs:bulkDownloadForm")
				.addParameter("javax.faces.partial.render", "documentTypeTabs:bulkDownloadForm:downloadTable")
				.addParameter("documentTypeTabs:bulkDownloadForm:btnContinue",
						"documentTypeTabs:bulkDownloadForm:btnContinue")
				.addParameter("documentTypeTabs:bulkDownloadForm", "documentTypeTabs:bulkDownloadForm")
				.addParameter("documentTypeTabs:bulkDownloadForm:selectDownloadFormat_input", "Formatted")
				.addParameter("documentTypeTabs:bulkDownloadForm:selectDownloadFormat_focus", "")
				.addParameter("documentTypeTabs:bulkDownloadForm:downloadTable_selection",
						adFile.getContentId() + adFile.getFileSize() + adFile.getContentId() + ".txt")
				.addParameter("documentTypeTabs:bulkDownloadForm:downloadTable_scrollState", "0,0")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenSelectedIDs",
						"[" + new ObjectMapper().writeValueAsString(adFile) + "]")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenNodeId", "")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenMaxSize", "20971520")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenActive", "false")
				.addParameter("javax.faces.ViewState", session.getState()).build();
		request.setHeader("Origin", "https://betagrid.gxs.com");
		request.setHeader("Upgrade-Insecure-Requests", "1");
		request.setHeader("Content-Type", "application/x-www-form-urlencoded");
		request.setHeader("User-Agent",
				"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
		request.setHeader("Faces-Request", "partial/ajax");
		request.setHeader("X-Requested-With", "XMLHttpRequest");
		request.setHeader("Accept",
				"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
		request.setHeader("Referer",
				"https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw?fileId=" + session.getActiveDocuments()[0]
						+ "&processId=" + session.getActiveDocuments()[0] + "&contentType=FILE");
		request.setHeader("Accept-Encoding", "gzip, deflate, br");
		request.setHeader("Accept-Language", "en-US,en;q=0.8");
		request.setHeader("Cookie", generateCookie(session.getCookies()) + "primefaces.download=true;");
		CloseableHttpResponse response = httpclient.execute(request);
		try {
			HttpEntity entity = response.getEntity();
			handleSetCookie(session.getCookies(), response);
			EntityUtils.consume(entity);
		} finally {
			response.close();
		}
	}

	public static void exportFileStep2(CloseableHttpClient httpclient, Session session, ADFile adFile, String dir)
			throws Exception {
		HttpUriRequest request = RequestBuilder.post()
				.setUri(new URI("https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw"))
				.addParameter("documentTypeTabs:bulkDownloadForm", "documentTypeTabs:bulkDownloadForm")
				.addParameter("documentTypeTabs:bulkDownloadForm:btnBulkDownload", "")
				.addParameter("documentTypeTabs:bulkDownloadForm:downloadTable_scrollState", "0,0")
				.addParameter("documentTypeTabs:bulkDownloadForm:downloadTable_selection",
						adFile.getContentId() + adFile.getFileSize() + adFile.getContentId() + ".txt")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenActive", "false")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenMaxSize", "20971520")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenNodeId", "")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenSelectedIDs",
						"[" + new ObjectMapper().writeValueAsString(adFile) + "]")
				.addParameter("documentTypeTabs:bulkDownloadForm:selectDownloadFormat_focus", "")
				.addParameter("documentTypeTabs:bulkDownloadForm:selectDownloadFormat_input", "Formatted")
				.addParameter("javax.faces.ViewState", session.getState()).build();
		request.setHeader("Origin", "https://betagrid.gxs.com");
		request.setHeader("Upgrade-Insecure-Requests", "1");
		request.setHeader("Content-Type", "application/x-www-form-urlencoded");
		request.setHeader("User-Agent",
				"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
		request.setHeader("Accept",
				"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
		request.setHeader("Accept-Encoding", "gzip, deflate, br");
		request.setHeader("Accept-Language", "en-US,en;q=0.8");
		request.setHeader("Cookie", generateCookie(session.getCookies()) + "primefaces.download=true;");
		CloseableHttpResponse response = httpclient.execute(request);
		InputStream is = null;
		FileOutputStream fos = null;
		try {
			HttpEntity entity = response.getEntity();
			handleSetCookie(session.getCookies(), response);

			String filePath = dir + adFile.getContentId() + "_"
					+ adFile.getFileName();
			is = entity.getContent();
			fos = new FileOutputStream(new File(filePath));
			byte[] buffer = new byte[8 * 1024];
			int bytesRead;
			while ((bytesRead = is.read(buffer)) != -1) {
				fos.write(buffer, 0, bytesRead);
			}
			EntityUtils.consume(entity);
		} finally {
			response.close();
			if (is != null) {
				is.close();
			}
			if (fos != null) {
				fos.close();
			}
		}
	}

	private static void downloadPDF(CloseableHttpClient httpclient, Hashtable<String, String> cookies, String state)
			throws Exception {
		HttpUriRequest request = RequestBuilder.post()
				.setUri(new URI("https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw"))
				.addParameter("documentTypeTabs:lifecycleForm", "documentTypeTabs:lifecycleForm")
				// .addParameter("documentTypeTabs:lifecycleForm:doc_header_info_panel_collapsed",
				// "false")
				// .addParameter("documentTypeTabs:lifecycleForm:doc_lc_details_panel_collapsed",
				// "false")
				.addParameter("documentTypeTabs:lifecycleForm:j_idt393", "")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetName",
				// "")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetType",
				// "")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetURI",
				// "")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputFileSetType",
				// "")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileSetId",
				// "")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileType",
				// "")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputFileSetType",
				// "")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileSetId",
				// "")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileType",
				// "")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentStepName",
				// "")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileSetId",
				// "3-AIKEY~18909851~BMS23DCTS~MS23T~")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileType",
				// "")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileSetId",
				// "3-AIKEY~18909851~BMS23DCTS~MS23T~")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileType",
				// "")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:processingStepTable_selection",
				// "")
				// .addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_activeIndex",
				// "0")
				.addParameter("javax.faces.ViewState", state).build();
		request.setHeader("Cookie", generateCookie(cookies));
		CloseableHttpResponse response = httpclient.execute(request);
		try {
			HttpEntity entity = response.getEntity();
			handleSetCookie(cookies, response);
			System.out.println(response.getStatusLine().getStatusCode());
			for (Header header : response.getAllHeaders()) {
				System.out.println(header.getName() + " = " + header.getValue());
			}

			InputStream is = entity.getContent();
			String filePath = "/Users/fanpanzeng/Documents/LDW_EDI_Testing/download.dat";
			FileOutputStream fos = new FileOutputStream(new File(filePath));
			int inByte;
			while ((inByte = is.read()) != -1)
				fos.write(inByte);
			is.close();
			fos.close();
			EntityUtils.consume(entity);
		} finally {
			response.close();
		}
	}

	private static void downloadOutput(CloseableHttpClient httpclient, Hashtable<String, String> cookies, String state)
			throws Exception {
		HttpUriRequest request = RequestBuilder.post()
				.setUri(new URI("https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw"))
				.addParameter("documentTypeTabs:lifecycleForm", "documentTypeTabs:lifecycleForm")
				.addParameter("documentTypeTabs:lifecycleForm:doc_header_info_panel_collapsed", "false")
				.addParameter("documentTypeTabs:lifecycleForm:doc_lc_details_panel_collapsed", "false")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetName", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentAssetURI", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputFileSetType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileSetId",
						"3-AIKEY~18909851~BMS23DCTS~MS23T~")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentInputsFileType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputFileSetType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileSetId",
						"3-AIKEY~18909851~BMS23DCTS~MS23T~")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentOutputsFileType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentStepName", "Translation")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileSetId",
						"3-AIKEY~18909851~BMS23DCTS~MS23T~")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationInputsFileType", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileSetId",
						"3-AIKEY~18909851~BMS23DCTS~MS23T~")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:hiddentTranslationOutputsFileType",
						"")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputOutputsRadio", "outputs")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable:0:menu",
						"documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable:0:menu")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable:0:menu_menuid",
						"2")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable:j_idt598:filter",
						"")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable:j_idt600:filter",
						"")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable_selection", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:processingStepTable_selection", "")
				.addParameter("documentTypeTabs:lifecycleForm:lifecycleDetailTabs_activeIndex", "1")
				.addParameter("javax.faces.ViewState", state).build();
		request.setHeader("Origin", "https://betagrid.gxs.com");
		request.setHeader("Upgrade-Insecure-Requests", "1");
		request.setHeader("Content-Type", "application/x-www-form-urlencoded");
		request.setHeader("User-Agent",
				"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
		request.setHeader("Accept",
				"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
		request.setHeader("Referer",
				"https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw?fileId=F-37742768&processId=F-37742768&contentType=FILE");
		request.setHeader("Accept-Encoding", "gzip, deflate, br");
		request.setHeader("Accept-Language", "en-US,en;q=0.8");
		request.setHeader("Cookie", generateCookie(cookies));

		CloseableHttpResponse response = httpclient.execute(request);
		try {
			HttpEntity entity = response.getEntity();
			handleSetCookie(cookies, response);
			System.out.println(response.getStatusLine().getStatusCode());
			for (Header header : response.getAllHeaders()) {
				System.out.println(header.getName() + " = " + header.getValue());
			}

			InputStream is = entity.getContent();
			String filePath = "/Users/fanpanzeng/Documents/LDW_EDI_Testing/download.dat";
			FileOutputStream fos = new FileOutputStream(new File(filePath));
			int inByte;
			while ((inByte = is.read()) != -1)
				fos.write(inByte);
			is.close();
			fos.close();
			EntityUtils.consume(entity);
		} finally {
			response.close();
		}
	}

	public static void exportOutput(CloseableHttpClient httpclient, Hashtable<String, String> cookies, String state)
			throws Exception {
		HttpUriRequest request0 = RequestBuilder.post()
				.setUri(new URI("https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw"))
				.addParameter("documentTypeTabs:bulkDownloadForm", "documentTypeTabs:bulkDownloadForm")
				.addParameter("documentTypeTabs:bulkDownloadForm:btnContinue",
						"documentTypeTabs:bulkDownloadForm:btnContinue")
				.addParameter("documentTypeTabs:bulkDownloadForm:downloadTable_scrollState", "0,0")
				.addParameter("documentTypeTabs:bulkDownloadForm:downloadTable_selection",
						// "F-3774277015406F-37742770.txt")
						"")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenActive", "false")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenMaxSize", "20971520")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenNodeId", "")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenSelectedIDs",
						// "[{\"contentId\":\"F-37742770\",\"fileName\":\"SAPQ02_000531248_20180703173851_0001.dat\",\"fileUri\":\"fileName=bms23dcts/DANONAIBR/03-JUL-2018/OUTPUT/SAPQ02_000531248_20180703173851_0001.dat.gz&GPID=MS23T&dataStore=DCTS\",\"fileSize\":\"15406\"}]")
						"[{\"contentId\":\"F-37870228\",\"fileName\":\"007347602DCO.0574540190000T.850EM.1.000545384\",\"fileUri\":\"fileName=bms23dcts/DANONAIBR/13-JUL-2018/OUTPUT/007347602DCO.0574540190000T.850EM.1.000545384.gz&GPID=MS23T&dataStore=DCTS\",\"fileSize\":\"18026\"}]")

				.addParameter("documentTypeTabs:bulkDownloadForm:selectDownloadFormat_focus", "")
				.addParameter("documentTypeTabs:bulkDownloadForm:selectDownloadFormat_input", "Formatted")
				.addParameter("javax.faces.partial.ajax", "true")
				.addParameter("javax.faces.partial.execute", "documentTypeTabs:bulkDownloadForm")
				.addParameter("javax.faces.partial.render", "documentTypeTabs:bulkDownloadForm:downloadTable")
				.addParameter("javax.faces.source", "documentTypeTabs:bulkDownloadForm:btnContinue")
				.addParameter("javax.faces.ViewState", state).build();
		request0.setHeader("Origin", "https://betagrid.gxs.com");
		request0.setHeader("Upgrade-Insecure-Requests", "1");
		request0.setHeader("Content-Type", "application/x-www-form-urlencoded");
		request0.setHeader("User-Agent",
				"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
		request0.setHeader("Faces-Request", "partial/ajax");
		request0.setHeader("X-Requested-With", "XMLHttpRequest");
		request0.setHeader("Accept",
				"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
		request0.setHeader("Referer",
				"https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw?fileId=F-37742768&processId=F-37742768&contentType=FILE");
		request0.setHeader("Accept-Encoding", "gzip, deflate, br");
		request0.setHeader("Accept-Language", "en-US,en;q=0.8");
		request0.setHeader("Cookie", generateCookie(cookies) + "primefaces.download=true;");
		System.out.println(generateCookie(cookies));
		CloseableHttpResponse response0 = httpclient.execute(request0);
		try {
			HttpEntity entity0 = response0.getEntity();
			handleSetCookie(cookies, response0);
			System.out.println(response0.getStatusLine().getStatusCode());
			for (Header header : response0.getAllHeaders()) {
				System.out.println(header.getName() + " = " + header.getValue());
			}

			InputStream is0 = entity0.getContent();
			String filePath0 = "/Users/fanpanzeng/Documents/LDW_EDI_Testing/download41.dat";
			FileOutputStream fos0 = new FileOutputStream(new File(filePath0));
			int inByte0;
			while ((inByte0 = is0.read()) != -1)
				fos0.write(inByte0);
			is0.close();
			fos0.close();
			EntityUtils.consume(entity0);
		} finally {
			response0.close();
		}

		HttpUriRequest request = RequestBuilder.post()
				.setUri(new URI("https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw"))
				.addParameter("documentTypeTabs:bulkDownloadForm", "documentTypeTabs:bulkDownloadForm")
				.addParameter("documentTypeTabs:bulkDownloadForm:btnBulkDownload", "")
				.addParameter("documentTypeTabs:bulkDownloadForm:downloadTable_scrollState", "0,0")
				.addParameter("documentTypeTabs:bulkDownloadForm:downloadTable_selection",
						// "F-3774277015406F-37742770.txt")
						"")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenActive", "false")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenMaxSize", "20971520")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenNodeId", "")
				.addParameter("documentTypeTabs:bulkDownloadForm:hiddenSelectedIDs",
						// "[{\"contentId\":\"F-37742770\",\"fileName\":\"SAPQ02_000531248_20180703173851_0001.dat\",\"fileUri\":\"fileName=bms23dcts/DANONAIBR/03-JUL-2018/OUTPUT/SAPQ02_000531248_20180703173851_0001.dat.gz&GPID=MS23T&dataStore=DCTS\",\"fileSize\":\"15406\"}]")
						"[{\"contentId\":\"F-37870228\",\"fileName\":\"007347602DCO.0574540190000T.850EM.1.000545384\",\"fileUri\":\"fileName=bms23dcts/DANONAIBR/13-JUL-2018/OUTPUT/007347602DCO.0574540190000T.850EM.1.000545384.gz&GPID=MS23T&dataStore=DCTS\",\"fileSize\":\"18026\"}]")
				.addParameter("documentTypeTabs:bulkDownloadForm:selectDownloadFormat_focus", "")
				.addParameter("documentTypeTabs:bulkDownloadForm:selectDownloadFormat_input", "Formatted")
				.addParameter("javax.faces.ViewState", state).build();
		request.setHeader("Origin", "https://betagrid.gxs.com");
		request.setHeader("Upgrade-Insecure-Requests", "1");
		request.setHeader("Content-Type", "application/x-www-form-urlencoded");
		request.setHeader("User-Agent",
				"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
		request.setHeader("Accept",
				"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
		request.setHeader("Referer",
				"https://betagrid.gxs.com/adweb/lifecycle/lifecycle.adw?fileId=F-37742768&processId=F-37742768&contentType=FILE");
		request.setHeader("Accept-Encoding", "gzip, deflate, br");
		request.setHeader("Accept-Language", "en-US,en;q=0.8");
		request.setHeader("Cookie", generateCookie(cookies) + "primefaces.download=true;");
		System.out.println(generateCookie(cookies));
		CloseableHttpResponse response = httpclient.execute(request);
		try {
			HttpEntity entity = response.getEntity();
			handleSetCookie(cookies, response);
			System.out.println(response.getStatusLine().getStatusCode());
			for (Header header : response.getAllHeaders()) {
				System.out.println(header.getName() + " = " + header.getValue());
			}

			InputStream is = entity.getContent();
			String filePath = "/Users/fanpanzeng/Documents/LDW_EDI_Testing/download42.dat";
			FileOutputStream fos = new FileOutputStream(new File(filePath));
			int inByte;
			while ((inByte = is.read()) != -1)
				fos.write(inByte);
			is.close();
			fos.close();
			EntityUtils.consume(entity);
		} finally {
			response.close();
		}
	}

	private static void handleSetCookie(Hashtable<String, String> cookies, HttpResponse response) {
		for (Header header : response.getAllHeaders()) {
			if (header.getName().equals("Set-Cookie")) {
				String headerValue = header.getValue().split(";")[0];
				String cookieName = headerValue.substring(0, headerValue.indexOf('='));
				String cookieValue = headerValue.substring(headerValue.indexOf('=') + 1);
				if (cookieValue.isEmpty() || cookieValue.equals("QUIT")) {
					cookies.remove(cookieName);
				} else {
					cookies.put(cookieName, cookieValue);
				}
			}
		}
	}

	private static String generateCookie(Hashtable<String, String> cookies) {
		String cookie = "";
		for (String cookieName : cookies.keySet()) {
			cookie = cookie + cookieName + "=" + cookies.get(cookieName) + ";";
		}
		return cookie;
	}
	
}
