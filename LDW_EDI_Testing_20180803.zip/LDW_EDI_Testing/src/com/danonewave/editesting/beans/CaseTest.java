package com.danonewave.editesting.beans;

import java.util.Date;

public class CaseTest implements Comparable<CaseTest>{

	private Date timestamp;
	private String mapName;
	private String reportFile;
	private String result;

	public CaseTest(Date timestamp, String mapName) {
		this.timestamp = timestamp;
		this.mapName = mapName;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public String getMapName() {
		return mapName;
	}

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public String getReportFile() {
		return reportFile;
	}

	public void setReportFile(String reportFile) {
		this.reportFile = reportFile;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	@Override
	public int compareTo(CaseTest caseTest) {
		return caseTest.timestamp.compareTo(this.timestamp);
	}
}
