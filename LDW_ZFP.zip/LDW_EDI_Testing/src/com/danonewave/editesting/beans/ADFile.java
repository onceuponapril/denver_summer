package com.danonewave.editesting.beans;

public class ADFile {
	private String contentId;
	private String fileName;
	private String fileUri;
	private String fileSize;
	
	public ADFile(String contentId, String fileName, String fileUri, String fileSize){
		this.contentId = contentId;
		this.fileName = fileName;
		this.fileUri = fileUri;
		this.fileSize = fileSize;
	}
	public String getContentId() {
		return contentId;
	}
	public void setContentId(String contentId) {
		this.contentId = contentId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileUri() {
		return fileUri;
	}
	public void setFileUri(String fileUri) {
		this.fileUri = fileUri;
	}
	public String getFileSize() {
		return fileSize;
	}
	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}
}