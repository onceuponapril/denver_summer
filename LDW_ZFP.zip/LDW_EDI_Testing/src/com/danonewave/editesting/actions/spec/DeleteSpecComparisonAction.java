package com.danonewave.editesting.actions.spec;

import java.io.File;
import java.io.FilenameFilter;


import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.SpecComparison;
import com.opensymphony.xwork2.ActionSupport;

public class DeleteSpecComparisonAction extends ActionSupport{
	private static final long serialVersionUID = -8924917016380496947L;
	private String timestamp;
	

	public void setTimestamp(String timestamp){
		this.timestamp = timestamp;
	}
	
	@Override
	public String execute() throws Exception {
		String specComparisonDir = ServletActionContext.getServletContext().getInitParameter("localDir")
				+ SpecComparison.FOLDER;
		for (String filename : new File(specComparisonDir).list(new FilenameFilter(){

			@Override
			public boolean accept(File dir, String name) {
				if (name.startsWith(timestamp)){
					return true;
				}
				return false;
			}})){
			new File(specComparisonDir + File.separator + filename).delete();
		}
	    return SUCCESS;
	}

}
