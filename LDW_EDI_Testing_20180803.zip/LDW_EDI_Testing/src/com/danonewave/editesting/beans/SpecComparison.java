package com.danonewave.editesting.beans;

import java.util.Date;

public class SpecComparison implements Comparable<SpecComparison> {
	public final static String FOLDER = "SpecComparison";
	private Date timestamp;
	private String mapNames;
	private String result;
	private String reportFile;

	public SpecComparison(Date timestamp, String mapNames, String result, String reportFile) {
		this.timestamp = timestamp;
		this.mapNames = mapNames;
		this.result = result;
		this.reportFile = reportFile;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public String getMapNames() {
		return mapNames;
	}

	public void setMapNames(String mapNames) {
		this.mapNames = mapNames;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getReportFile() {
		return reportFile;
	}

	public void setReportFile(String reportFile) {
		this.reportFile = reportFile;
	}

	@Override
	public int compareTo(SpecComparison specComparison) {
		return specComparison.timestamp.compareTo(this.timestamp);
	}
	
}
