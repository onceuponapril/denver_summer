package com.danonewave.editesting.beans;

public class Spec {
	public final static String FOLDER = "Spec";
	private String mapName;
	private String specVersion;
	private String specFile;

	public Spec(String mapName, String specVersion, String specFile) {
		this.mapName = mapName;
		this.specVersion =specVersion;
		this.specFile = specFile;
	}

	public String getMapName() {
		return mapName;
	}

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public String getSpecVersion() {
		return specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getSpecFile() {
		return specFile;
	}

	public void setSpecFile(String specFile) {
		this.specFile = specFile;
	}

}
