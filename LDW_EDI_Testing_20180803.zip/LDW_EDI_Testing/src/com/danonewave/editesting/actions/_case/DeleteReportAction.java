package com.danonewave.editesting.actions._case;

import java.io.File;
import java.io.FilenameFilter;

import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.Case;
import com.opensymphony.xwork2.ActionSupport;

public class DeleteReportAction extends ActionSupport {
	private static final long serialVersionUID = 46126494184181589L;
	private String timestamp;

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String execute() throws Exception {
		File testDir = new File(((String) ServletActionContext.getServletContext().getInitParameter("localDir"))
				+ Case.TEST_FOLDER + File.separator);
		for (String filename : testDir.list(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				if (name.startsWith(timestamp)) {
					return true;
				}
				return false;
			}
		})) {
			new File(testDir.getAbsolutePath() + File.separator + filename).delete();
		}
		return SUCCESS;
	}

}
