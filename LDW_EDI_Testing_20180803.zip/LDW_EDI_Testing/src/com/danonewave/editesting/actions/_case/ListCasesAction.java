package com.danonewave.editesting.actions._case;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;

import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.Case;
import com.danonewave.editesting.beans.Spec;
import com.danonewave.editesting.utils.SpecUtil;
import com.opensymphony.xwork2.ActionSupport;

public class ListCasesAction extends ActionSupport {
	private static final long serialVersionUID = 2473716038889671906L;
	private String mapName;
	private List<Case> caseList;

	public List<Case> getCaseList() {
		return caseList;
	}

	public String getMapName() {
		return mapName;
	}

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public List<String> getMapNames() {
		return SpecUtil.listMapNames((String) ServletActionContext.getServletContext().getInitParameter("localDir")
				+ Spec.FOLDER + File.separator);
	}

	public String execute() throws Exception {
		if (mapName == null) {
			mapName = getMapNames().get(0);
		}
		Hashtable<String, Case> caseTable = new Hashtable<String, Case>();

		String caseDir = ((String) ServletActionContext.getServletContext().getInitParameter("localDir")) + Case.FOLDER
				+ File.separator + mapName + File.separator;

		if (!new File(caseDir).exists()) {
			new File(caseDir).mkdir();
		}

		for (String filename : new File(caseDir).list(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String filename) {
				if (filename.endsWith(".txt") || filename.endsWith(".properties")) {
					return true;
				}
				return false;
			}
		})) {
			Case _case = null;
			if (filename.endsWith(".txt")) {
				int index = filename.indexOf("_");
				String caseName = filename.substring(0, index);
				String type = filename.substring(index + 1, filename.length() - 4);

				if (caseTable.containsKey(caseName)) {
					_case = caseTable.get(caseName);
				} else {
					_case = new Case(caseName);
					caseTable.put(caseName, _case);
				}

				switch (type) {
				case "input":
					_case.setInputFile(filename);
					break;
				case "output":
					_case.setOutputFile(filename);
					break;
				}
			} else if (filename.endsWith(".properties")) {
				int index = filename.indexOf(".");
				String caseName = filename.substring(0, index);
				if (caseTable.containsKey(caseName)) {
					_case = caseTable.get(caseName);
				} else {
					_case = new Case(caseName);
					caseTable.put(caseName, _case);
				}
				Properties properties = new Properties();
				Reader reader = null;
				try {
					reader = new FileReader(new File(caseDir + filename));
					properties.load(reader);
					_case.setOutputFilePattern(properties.getProperty(Case.KEY_PATTERN));
					_case.setRecords(properties.getProperty(Case.KEY_RECORDS).split(";"));
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} finally {
					if (reader != null) {
						reader.close();
					}
				}
			}

		}

		caseList = new ArrayList<Case>(caseTable.values());
		return SUCCESS;
	}
}
