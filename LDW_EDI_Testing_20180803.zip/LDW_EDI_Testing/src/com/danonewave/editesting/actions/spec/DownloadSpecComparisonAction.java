package com.danonewave.editesting.actions.spec;

import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.InputStream;

import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.SpecComparison;
import com.opensymphony.xwork2.ActionSupport;

public class DownloadSpecComparisonAction extends ActionSupport {
	private static final long serialVersionUID = 7982076222220686267L;
	private String timestamp;
	private String fileName;
	private long contentLength;
	private InputStream fileInputStream;

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getFileName() {
		return fileName;
	}
	
	public InputStream getFileInputStream() {
		return fileInputStream;
	}

	public long getContentLength() {
		return contentLength;
	}

	public String execute() throws Exception {
		String specComparisonDir = (String) ServletActionContext.getServletContext().getInitParameter("localDir")
				+ SpecComparison.FOLDER;
		for (String filename : new File(specComparisonDir).list(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String filename) {
				if (filename.startsWith(timestamp) && filename.endsWith("report.xlsx")) {
					return true;
				}
				return false;
			}
		})) {

			File file = new File(specComparisonDir + File.separator + filename);
			fileName = filename;
			fileInputStream = new FileInputStream(file);
			contentLength = file.length();
		}
		return SUCCESS;
	}

}
