package com.danonewave.editesting.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Pattern;

import com.danonewave.editesting.beans.EDI;

public class EDIUtil {
	public static EDI readEDI(File ediFile) {
		EDI edi = new EDI();

		FileReader ediFileReader = null;
		BufferedReader ediBufferedReader = null;
		try {
			ediFileReader = new FileReader(ediFile);
			ediBufferedReader = new BufferedReader(ediFileReader);

			String ediLine;
			int ediLineNum = 0;
			String fieldDelimiter = "\\*";

			while ((ediLine = ediBufferedReader.readLine()) != null) {
				ediLineNum = ediLineNum + 1;
				if (ediLineNum == 1) {
					fieldDelimiter = ediLine.substring(ediLine.length() - 3, ediLine.length() - 2);
				}
				String[] ediFields = ediLine.split(Pattern.quote(fieldDelimiter));
				String ediSegment = ediFields[0];
				switch (ediSegment) {
				case "ISA":
					edi.setSender(ediFields[6].trim());
					edi.setVersion(ediFields[12].trim());
					break;
				case "GS":
					edi.setFunctionalGroup(ediFields[1].trim());
					break;
				case "ST":
					edi.setTransaction(ediFields[1].trim());
					return edi;
				}
			}
		} catch (IOException e) {
			return null;
		} finally {
			if (ediFileReader != null) {
				try {
					ediFileReader.close();
				} catch (IOException e) {
				}
			}
			
			if (ediBufferedReader != null) {
				try {
					ediBufferedReader.close();
				} catch (IOException e) {
				}
			}
		}
		return null;
	}
}
