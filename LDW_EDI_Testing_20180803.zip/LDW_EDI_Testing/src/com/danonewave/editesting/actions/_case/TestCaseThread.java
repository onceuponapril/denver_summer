package com.danonewave.editesting.actions._case;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;

import javax.servlet.ServletContext;

import com.danonewave.editesting.actions.activedocument.CheckActiveDocumentAction;
import com.danonewave.editesting.actions.activedocument.ListActiveDocumentsAction;
import com.danonewave.editesting.actions.activedocument.UploadInputAction;
import com.danonewave.editesting.beans.ADFile;
import com.danonewave.editesting.beans.ActiveDocument;
import com.danonewave.editesting.beans.Case;
import com.danonewave.editesting.utils.IDocComparator;

public class TestCaseThread extends Thread {
	private String mapName;
	private String[] caseNames;
	private ServletContext servletContext;

	public TestCaseThread(String mapName, String[] caseNames, ServletContext servletContext) {
		this.mapName = mapName;
		this.caseNames = caseNames;
		this.servletContext = servletContext;
	}

	public void run() {
		StringBuffer reportStringBuffer = new StringBuffer();
		String timestamp = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
		String caseDir = ((String) servletContext.getInitParameter("localDir")) + Case.FOLDER + File.separator + mapName
				+ File.separator;
		String testDir = ((String) servletContext.getInitParameter("localDir")) + Case.TEST_FOLDER + File.separator;
		String activeDocumentDir = ((String) servletContext.getInitParameter("localDir")) + ActiveDocument.FOLDER
				+ File.separator;

		PrintWriter resultFileWriter = null;
		try {
			resultFileWriter = new PrintWriter(testDir + timestamp + "_" + mapName + "_result.txt");
			resultFileWriter.write("Processing");
		} catch (FileNotFoundException e) {
		} finally {
			if (resultFileWriter != null) {
				resultFileWriter.close();
			}
		}
		Hashtable<String, String> casesTable = new Hashtable<String, String>();

		for (String caseName : caseNames) {
			UploadInputAction uploadInputAction = new UploadInputAction(servletContext);
			uploadInputAction.setMapName(mapName);
			uploadInputAction.setCopyFrom(new File(caseDir + caseName + "_input.txt"));
			try {
				uploadInputAction.execute();
			} catch (Exception e) {
				e.printStackTrace();
			}
			String caseId = uploadInputAction.getTimestamp();
			casesTable.put(caseId, caseName);
			try {
				Thread.sleep(1000L * 60 * 5);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			CheckActiveDocumentAction checkActiveDocumentAction = new CheckActiveDocumentAction(servletContext);
			checkActiveDocumentAction.setMapName(mapName);
			checkActiveDocumentAction.setTimestamp(caseId);
			checkActiveDocumentAction.execute();
		}

		ListActiveDocumentsAction listActiveDocumentsAction = new ListActiveDocumentsAction(servletContext);
		listActiveDocumentsAction.setTimestamps(casesTable.keySet());
		try {
			listActiveDocumentsAction.execute();
			for (ActiveDocument activeDocument : listActiveDocumentsAction.getActiveDocumentList()) {
				String caseId = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(activeDocument.getTimestamp());
				Case _case = IDocComparator.getCase(casesTable.get(caseId), servletContext, mapName);
				String outputPattern = _case.getOutputFilePattern();
				String[] records = _case.getRecords();
				reportStringBuffer.append(caseId + ";" + mapName + ";" + _case.getCaseName() + ";");
				String compareResult = "Unknown";
				for (ADFile output : activeDocument.getOutputFiles()) {
					String outputFilename = output.getFileName();
					if (outputFilename.matches(outputPattern)) {
						compareResult = IDocComparator.compare(new File(activeDocumentDir + output.getFileUri()),
								new File(caseDir + _case.getOutputFile()), records);
						break;
					}
				}
				reportStringBuffer.append(compareResult + "\n");
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		PrintWriter reportFileWriter = null;
		try {
			reportFileWriter = new PrintWriter(testDir + timestamp + "_" + mapName + "_report.txt");
			reportFileWriter.write(reportStringBuffer.toString());
		} catch (FileNotFoundException e) {
		} finally {
			if (reportFileWriter != null) {
				reportFileWriter.close();
			}
		}

		PrintWriter resultFileWriter2 = null;
		try {
			resultFileWriter2 = new PrintWriter(testDir + timestamp + "_" + mapName + "_result.txt");
			resultFileWriter2.write("Done");
		} catch (FileNotFoundException e) {
		} finally {
			if (resultFileWriter2 != null) {
				resultFileWriter2.close();
			}
		}
	}

}
