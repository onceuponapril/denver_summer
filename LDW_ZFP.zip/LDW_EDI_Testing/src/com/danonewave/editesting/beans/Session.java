package com.danonewave.editesting.beans;

import java.util.Hashtable;

public class Session {
	private Hashtable<String, String> cookies;
	private String[] activeDocuments;
	private String state;
	private String translationStepId;
	private ADFile[] inputs;
	private ADFile[] outputs;
	private String errorCount;
	private ErrorFile[] errorFile;
	
	public ErrorFile[] getErrorFile() {
		return errorFile;
	}

	public void setErrorFile(ErrorFile[] errorFile) {
		this.errorFile = errorFile;
	}

	public String getErrorCount() {
		return errorCount;
	}

	public void setErrorCount(String errorCount) {
		this.errorCount = errorCount;
	}

	
	
	public Session(){
		cookies = new Hashtable<String, String>();
	}
	
	public Hashtable<String, String> getCookies() {
		return cookies;
	}

	public void setCookies(Hashtable<String, String> cookies) {
		this.cookies = cookies;
	}

	public String[] getActiveDocuments() {
		return activeDocuments;
	}

	public void setActiveDocuments(String[] activeDocuments) {
		this.activeDocuments = activeDocuments;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getTranslationStepId() {
		return translationStepId;
	}

	public void setTranslationStepId(String translationStepId) {
		this.translationStepId = translationStepId;
	}


	public ADFile[] getInputs() {
		return inputs;
	}

	public void setInputs(ADFile[] inputs) {
		this.inputs = inputs;
	}
	


	public ADFile[] getOutputs() {
		return outputs;
	}

	public void setOutputs(ADFile[] outputs) {
		this.outputs = outputs;
	}
	

	
}


