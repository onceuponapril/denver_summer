package com.danonewave.editesting.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Properties;

import javax.servlet.ServletContext;

import com.danonewave.editesting.beans.Case;

public class IDocComparator {

	public static Case getCase(String caseName, ServletContext servletContext, String mapName) {
		String caseDir = ((String) servletContext.getInitParameter("localDir")) + Case.FOLDER + File.separator + mapName
				+ File.separator;
		Properties properties = new Properties();
		Reader reader = null;
		Case _case = new Case(caseName);
		try {
			reader = new FileReader(new File(caseDir + caseName + ".properties"));
			properties.load(reader);
			_case.setOutputFilePattern(properties.getProperty(Case.KEY_PATTERN));
			_case.setRecords(properties.getProperty(Case.KEY_RECORDS).split(";"));
			_case.setOutputFile(caseName + "_output.txt");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return _case;
	}

	public static String compare(File output, File expected, String[] records) {
		FileReader outputFileReader = null;
		FileReader expectedFileReader = null;

		String message = "Passed";
		try {
			outputFileReader = new FileReader(output);
			expectedFileReader = new FileReader(expected);
			BufferedReader outputFileBufferedReader = new BufferedReader(outputFileReader);
			BufferedReader expectedFileBufferedReader = new BufferedReader(expectedFileReader);

			String outputLine;
			String expectedLine;
			int outputLineNum = 0;
			test: while ((outputLine = outputFileBufferedReader.readLine()) != null) {
				outputLineNum = outputLineNum + 1;
				for (String record : records) {
					if (outputLine.startsWith(record)) {
						while ((expectedLine = expectedFileBufferedReader.readLine()) != null) {
							if (expectedLine.startsWith(record)) {
								if (!outputLine.equals(expectedLine)) {
									message = "Not found matched segment in output: " + record + " at line "
											+ outputLineNum;
									break test;
								} else {
									break;
								}
							}
						}
						break;
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			message = e.toString();
		} finally {
			if (outputFileReader != null) {
				try {
					outputFileReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			if (expectedFileReader != null) {
				try {
					expectedFileReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return message;
	}
}
