package com.danonewave.editesting.beans;

public class Mapping {
	private int rowNum;
	private String record;
	private String field;
	private String[] content;
	private boolean hidden;
	private boolean processed;
	
	public Mapping(int rowNum, String record, String field, boolean hidden, String[] content){
		this.rowNum = rowNum;
		this.record = record;
		this.field = field;
		this.hidden = hidden;
		this.content = content;
		processed = false;
	}

	public int getRowNum(){
		return rowNum;
	}
	
	public String getRecord() {
		return record;
	}

	public String getField() {
		return field;
	}

	public boolean isHidden(){
		return hidden;
	}
	
	public String[] getContent() {
		return content;
	}
	
	public boolean isProcessed(){
		return processed;
	}
	
	public void setProcessed(){
		processed = true;
	}
}
