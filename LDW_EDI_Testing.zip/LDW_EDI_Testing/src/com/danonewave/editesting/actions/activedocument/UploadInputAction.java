package com.danonewave.editesting.actions.activedocument;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.beans.ActiveDocument;
import com.opensymphony.xwork2.ActionSupport;

public class UploadInputAction extends ActionSupport {
	private static final long serialVersionUID = 8591197875263329616L;
	private String mapName;
	private File origin;

	public void setMapName(String mapName) {
		this.mapName = mapName;
	}

	public void setOrigin(File origin) {
		this.origin = origin;
	}

	public void setOriginContentType(String originContentType) {

	}

	public void setOriginFileName(String originFileName) {

	}

	public String execute() {
		String message = null;
		String timestamp = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
		String activeDocumentDir = ((String) ServletActionContext.getServletContext().getInitParameter("localDir"))
				+ ActiveDocument.FOLDER + File.separator;
		File newOrigin = new File(activeDocumentDir + timestamp + "_" + mapName + "_origin.txt");
		if (origin.renameTo(newOrigin)) {
			message = "Succeed to store to local";
			origin = newOrigin;
			if (ftpUpload()) {
				message = "Succeed to upload to FTP";
			} else {
				message = "Failed to upload to FTP";
			}
		} else {
			message = "Failed to store to local";
		}

		PrintWriter resultFileWriter = null;
		try {
			resultFileWriter = new PrintWriter(activeDocumentDir + timestamp + "_" + mapName + "_result.txt");
			resultFileWriter.write(message);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (resultFileWriter != null) {
				resultFileWriter.close();
			}
		}
		return SUCCESS;
	}

	private boolean ftpUpload() {
		InputStream inputStream = null;
		FTPClient ftp = new FTPClient();
		try {
			ftp.connect("bizsimu1.frmon.danet");
			ftp.login("biz", (String) ServletActionContext.getServletContext().getInitParameter("ftpPassword"));
			ftp.enterLocalPassiveMode();
			ftp.changeWorkingDirectory("/edi/AS2T1/data/GXS_inbound_test");
			inputStream = new FileInputStream(origin);
			return ftp.storeFile(origin.getName(), inputStream);
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			if (ftp.isConnected()) {
				try {
					ftp.logout();
					ftp.disconnect();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
