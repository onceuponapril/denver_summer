package com.danonewave.editesting.actions.activedocument;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.danonewave.editesting.actions.target2.CompareTarget2Action;
import com.danonewave.editesting.beans.ActiveDocument;
import com.danonewave.editesting.beans.Target2;
import com.opensymphony.xwork2.ActionSupport;

public class CompareActiveDocumentAction extends ActionSupport {

	private static final long serialVersionUID = 5858294942856859621L;
	private String outputFile;

	public void setOutputFile(String outputFile) {
		this.outputFile = outputFile;
	}
	
	public String execute() {
		String timestamp = outputFile.substring(0, 17);
		File activeDocumentDir = new File(((String) ServletActionContext.getServletContext().getInitParameter("localDir")) + ActiveDocument.FOLDER );
		
		for (String filename : activeDocumentDir.list())
		{
			if (filename.startsWith(timestamp) && filename.endsWith("origin.txt")){
				String mapName = filename.substring(filename.indexOf("_") + 1, filename.lastIndexOf("_"));
				File ediFile = new File(((String) ServletActionContext.getServletContext().getInitParameter("localDir")) + Target2.FOLDER + File.separator + filename);
				File emailFile = new File(((String) ServletActionContext.getServletContext().getInitParameter("localDir")) + Target2.FOLDER + File.separator + outputFile);
				try {
					FileUtils.copyFile(new File(((String) ServletActionContext.getServletContext().getInitParameter("localDir")) + ActiveDocument.FOLDER + File.separator + outputFile), emailFile);
					FileUtils.copyFile(new File(((String) ServletActionContext.getServletContext().getInitParameter("localDir")) + ActiveDocument.FOLDER + File.separator + filename), ediFile);
					CompareTarget2Action ct2 = new CompareTarget2Action();
					ct2.setEdiFile(ediFile);
					ct2.setEmailFile(emailFile);
					ct2.setMapName(mapName);
					return ct2.execute();
				} catch (IOException e) {
					e.printStackTrace();
					return ERROR;
				}
			}
		}
		return ERROR;
	}

	
}
