package com.danonewave.editesting.utils;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;

import com.danonewave.editesting.beans.ADFile;
import com.danonewave.editesting.beans.ErrorFile;

public class HTMLUtil {
	public static String retrieveState(String htmlString) {
		Document doc = Jsoup.parse(htmlString);
		for (Element element : doc.getElementsByTag("input")) {
			if (element.hasAttr("name") && element.attr("name").equals("javax.faces.ViewState")) {
				return element.attr("value");
			}
		}
		return null;
	}
	
	public static String[] retrieveADFromQueryResponse(String htmlString) {
		List<String> activeDocuments = new ArrayList<String>();
		Document doc = Jsoup.parse(htmlString);
		for (Element tableElement : doc.getElementsByTag("table")) {
			if (tableElement.hasClass("list-search")){
				for (Element trElement : tableElement.getElementsByTag("tr")){
					if (trElement.hasAttr("data-rk") && !trElement.attr("data-rk").trim().isEmpty()){
						activeDocuments.add(trElement.attr("data-rk"));
					}
				}
			}
		}
		return activeDocuments.toArray(new String[activeDocuments.size()]);
	}
	
	public static String retrieveTranslationStepId(String htmlString) {
		Document doc = Jsoup.parse(htmlString);
		for (Element element : doc.getElementsByTag("div")) {
			if (element.hasAttr("data-name") && element.attr("data-name").equals("Translation")) {
				return element.attr("data-stepid");
			}
		}
		return null;
	}
	
	public static ADFile[] retrieveInputsOutputs(String htmlString) {
		List<ADFile> outputs = new ArrayList<ADFile>();
		Document doc = Jsoup.parse(htmlString);
		Element tbody = doc.getElementById("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable_data");
		for (Node tr : tbody.childNodes()){
			String fileSize = ((Element)tr.childNode(4)).html();
			if (!fileSize.equals("0")){
				String contentId = ((Element)tr.childNode(1)).child(0).html();
				String fileName = ((Element)tr.childNode(2)).html();
				String fileUri = ((Element)tr.childNode(tr.childNodeSize() - 1)).html().replaceAll("&amp;", "&");
				outputs.add(new ADFile(contentId, fileName, fileUri, fileSize));
			}
		}
		return outputs.toArray(new ADFile[outputs.size()]);
	}


	public static String errorCount(String htmlString) {
		Document doc = Jsoup.parse(htmlString);
		Element list = doc.getElementById("documentTypeTabs:lifecycleForm:lifecycleDetailTabs"); 
		Elements liItems=list.select("ul").select("li");
		if(liItems.size()>2&&(liItems.get(1)).text().contains("Errors")) {
			String error=liItems.get(1).text();	 
			return error;
		}
		return null;
	}
	
   public static ErrorFile retrieveErrorInfo(String htmlString, ErrorFile errorFile) {
	   Document doc = Jsoup.parse(htmlString);
	   Element tbody=doc.getElementById("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable_data");
	   Elements td=tbody.getElementsByTag("td");
	   
	   errorFile.setErrorCode(td.get(3).text());
	   errorFile.setErrorStatus(td.get(4).text());
	   errorFile.setErrorDesc(td.get(5).text());
	   errorFile.setTrackingTime(td.get(6).text());
	   return errorFile;
			      
   }
   
   public static ErrorFile retrieveErrorMsg(String htmlString,ErrorFile errorFile) {
	   Document doc = Jsoup.parse(htmlString);
	   String errorMsg=doc.getElementById("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable:0:j_idt553").text();
	   errorFile.setErrorMsg(errorMsg);
	   return errorFile;
	   }

}