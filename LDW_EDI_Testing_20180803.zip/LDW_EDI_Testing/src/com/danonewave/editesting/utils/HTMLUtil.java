package com.danonewave.editesting.utils;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;

import com.danonewave.editesting.beans.ADError;
import com.danonewave.editesting.beans.ADFile;

public class HTMLUtil {
	public static String retrieveState(String htmlString) {
		Document doc = Jsoup.parse(htmlString);
		for (Element element : doc.getElementsByTag("input")) {
			if (element.hasAttr("name") && element.attr("name").equals("javax.faces.ViewState")) {
				return element.attr("value");
			}
		}
		return null;
	}

	public static String[] retrieveADFromQueryResponse(String htmlString) {
		List<String> activeDocuments = new ArrayList<String>();
		Document doc = Jsoup.parse(htmlString);
		for (Element tableElement : doc.getElementsByTag("table")) {
			if (tableElement.hasClass("list-search")) {
				for (Element trElement : tableElement.getElementsByTag("tr")) {
					if (trElement.hasAttr("data-rk") && !trElement.attr("data-rk").trim().isEmpty()) {
						activeDocuments.add(trElement.attr("data-rk"));
					}
				}
			}
		}
		return activeDocuments.toArray(new String[activeDocuments.size()]);
	}

	public static String retrieveTranslationStepId(String htmlString) {
		Document doc = Jsoup.parse(htmlString);
		for (Element element : doc.getElementsByTag("div")) {
			if (element.hasAttr("data-name") && element.attr("data-name").equals("Translation")) {
				return element.attr("data-stepid");
			}
		}
		return null;
	}

	public static ADFile[] retrieveInputsOutputs(String htmlString) {
		List<ADFile> outputs = new ArrayList<ADFile>();
		Document doc = Jsoup.parse(htmlString);
		Element tbody = doc
				.getElementById("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:inputsOutputsTable_data");
		for (Node tr : tbody.childNodes()) {
			if (tr.childNodeSize() >= 5) {
				String fileSize = ((Element) tr.childNode(4)).html();
				if (!fileSize.equals("0")) {
					String contentId = ((Element) tr.childNode(1)).child(0).html();
					String fileName = ((Element) tr.childNode(2)).html();
					String fileUri = ((Element) tr.childNode(tr.childNodeSize() - 1)).html().replaceAll("&amp;", "&");
					outputs.add(new ADFile(contentId, fileName, fileUri, fileSize));
				}
			}
		}
		return outputs.toArray(new ADFile[outputs.size()]);
	}

	public static String retrieveErrorCount(String htmlString) {
		Document doc = Jsoup.parse(htmlString);
		Element list = doc.getElementById("documentTypeTabs:lifecycleForm:lifecycleDetailTabs");
		Elements liItems = list.select("ul").select("li");
		if (liItems.size() > 2 && (liItems.get(1)).text().contains("Errors")) {
			String error = liItems.get(1).text();
			return error;
		}
		return null;
	}

	public static ADError[] retrieveErrors(String htmlString) {
		List<ADError> errors = new ArrayList<ADError>();
		Document doc = Jsoup.parse(htmlString);
		Element tbody = doc.getElementById("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable_data");
		for (Node tr : tbody.childNodes()) {
			errors.add(new ADError(((Element) tr.childNode(3)).text(), ((Element) tr.childNode(4)).text(),
					((Element) tr.childNode(5)).text(), null));
		}

		return errors.toArray(new ADError[errors.size()]);

	}

	public static String retrieveErrorMsg(String htmlString) {
		return Jsoup.parse(htmlString)
				.getElementById("documentTypeTabs:lifecycleForm:lifecycleDetailTabs:errorTable:0:j_idt553").text();
	}

}
