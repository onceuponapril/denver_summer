package com.danonewave.editesting.actions;

import javax.servlet.ServletContext;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

public class RunnableAction extends ActionSupport {
	private static final long serialVersionUID = 3822627273317805136L;
	ServletContext servletContext;
	
	public RunnableAction(){
		super();
	}
	
	public RunnableAction(ServletContext servletContext){
		this.servletContext = servletContext;
	}
	
	public String getParameter(String name){
		return servletContext == null ? ServletActionContext.getServletContext().getInitParameter(name) : servletContext.getInitParameter(name);
	}
}
