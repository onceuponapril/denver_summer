package com.danonewave.editesting.actions.target2;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Pagination
 */
public class Pagination extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Pagination() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
        response.setContentType("text/html;charset=UTF-8");
        
        int currentPage = Integer.valueOf(request.getParameter("currentPage"));
        int recordsPerPage = Integer.valueOf(request.getParameter("recordsPerPage"));
		String ipage=request.getParameter("page");
		int pageid=Integer.parseInt(ipage);
//		int recordsPerPage=5;
//		if(pageid==1) {
//			
//		}
//		else {
//			pageid=pageid-1;
//			pageid=pageid*recordsPerPage+1 
//		}
////		tagert2list
//		EmployeeDAO dao = new EmployeeDAO();
//        List<Employee> list = dao.viewAllEmployees((page-1)*recordsPerPage,
//                                 recordsPerPage);
//        int noOfRecords = dao.getNoOfRecords();
//        int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
//
//        request.setAttribute("noOfPages", noOfPages);
//        request.setAttribute("currentPage", page);
//		
//		RequestDispatcher view = request.getRequestDispatcher("list.jsp");
//		view.forward(request, response);
//	}
//
//	/**
//	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
//	 */
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		doGet(request, response);
	}

}
